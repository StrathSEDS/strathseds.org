---
title: GroupServ
author: MrRandom
layout: page
---
<a name="ACSNOLIMIT"><br /> <h2>
  ACSNOLIMIT
</h2>

<p>
  </a>
</p>

<p>
  ACSNOLIMIT allows a group to have a unlimited number of<br /> group access list entries.
</p>

<p>
  <strong>Syntax:</strong> <tt>ACSNOLIMIT <!group> ON|OFF</tt>
</p>

<p>
  <strong>Examples:</strong><br /> <br /><tt>/msg GroupServ ACSNOLIMIT !awesome-people ON</tt><br /> <a name="DROP"><br /> <h2>
    DROP
  </h2>
  
  <p>
    </a>
  </p>
  
  <p>
    DROP allows you to &#8220;unregister&#8221; a registered group.
  </p>
  
  <p>
    Once you DROP a group all of the data associated<br /> with it (access lists, metadata, etc) are removed and cannot<br /> be restored.
  </p>
  
  <p>
    See help on FLAGS for transferring a group to another user.
  </p>
  
  <p>
    <strong>Syntax:</strong> <tt>DROP <!group></tt>
  </p>
  
  <p>
    <strong>Examples:</strong><br /> <br /><tt>/msg GroupServ DROP !baz</tt><br /> <a name="FDROP"><br /> <h2>
      FDROP
    </h2>
    
    <p>
      </a>
    </p>
    
    <p>
      FDROP allows you to &#8220;unregister&#8221; a registered group.
    </p>
    
    <p>
      Once you FDROP a group all of the data associated<br /> with it (access lists, metadata, etc) are removed and cannot<br /> be restored.
    </p>
    
    <p>
      <strong>Syntax:</strong> <tt>FDROP <!group></tt>
    </p>
    
    <p>
      <strong>Examples:</strong><br /> <br /><tt>/msg GroupServ FDROP !baz</tt><br /> <a name="FFLAGS"><br /> <h2>
        FFLAGS
      </h2>
      
      <p>
        </a>
      </p>
      
      <p>
        The FFLAGS command allows an oper to force a flags<br /> change on a group. The syntax is the same as FLAGS,<br /> except that the target and flags changes must be given.<br /> Viewing any group&#8217;s access list is done with FLAGS.
      </p>
      
      <p>
        <strong>Syntax:</strong> <tt>FFLAGS <!group> <nickname> <flag_changes></tt>
      </p>
      
      <p>
        <strong>Examples:</strong><br /> <br /><tt>/msg GroupServ FFLAGS !baz foo +F</tt><br /> <br /><tt>/msg GroupServ FFLAGS !baz foo -*</tt><br /> <br /><tt>/msg GroupServ FFLAGS !baz foo +fmc</tt><br /> <a name="FLAGS"><br /> <h2>
          FLAGS
        </h2>
        
        <p>
          </a>
        </p>
        
        <p>
          The FLAGS command allows for the granting/removal of group<br /> privileges on a more specific, non-generalized level. It<br /> supports registered nicknames as targets.
        </p>
        
        <p>
          When only the group argument is given, a listing of<br /> permissions granted to users will be displayed.
        </p>
        
        <p>
          <strong>Syntax:</strong> <tt>FLAGS <!group></tt>
        </p>
        
        <p>
          You can modify a users&#8217; flags if you yourself have the +f flag.<br /> This has much the same syntax as chanserv/flags, using + to add<br /> flags to a user and &#8211; to remove flags from a user.
        </p>
        
        <p>
          <strong>Syntax:</strong> <tt>FLAGS <!group> [nickname flag_changes]</tt>
        </p>
        
        <p>
          Permissions:<br /> <br /><tt>+f - Enables modification of group access list.</tt><br /> <br /><tt>+F - Grants full founder access.</tt><br /> <br /><tt>+m - Read memos sent to the group.</tt><br /> <br /><tt>+c - Have channel access in channels where the group has sufficient</tt><br /> <br /><tt> privileges.</tt><br /> <br /><tt>+v - Take vhosts offered to the group through HostServ.</tt><br /> <br /><tt>+s - Ability to use GroupServ SET commands on the group.</tt><br /> <br /><tt>+b - Ban a user from the group. The user will not be able to join the</tt><br /> <br /><tt> group with the JOIN command and it will not show up in their</tt><br /> <br /><tt> NickServ INFO or anywhere else. NOTE that setting this flag will NOT</tt><br /> <br /><tt> automatically remove the users' privileges (if applicable).</tt>
        </p>
        
        <p>
          The special permission +* adds all permissions except +F.<br /> The special permission -* removes all permissions including +F.
        </p>
        
        <p>
          <strong>Examples:</strong><br /> <br /><tt>/msg GroupServ FLAGS !baz</tt><br /> <br /><tt>/msg GroupServ FLAGS !baz foo +F</tt><br /> <br /><tt>/msg GroupServ FLAGS !baz foo -*</tt><br /> <br /><tt>/msg GroupServ FLAGS !baz foo +fmc</tt><br /> <a name="INFO"><br /> <h2>
            INFO
          </h2>
          
          <p>
            </a>
          </p>
          
          <p>
            INFO displays group information such as<br /> registration time, group URL, email address<br /> and founder.
          </p>
          
          <p>
            <strong>Syntax:</strong> <tt>INFO <!group></tt>
          </p>
          
          <p>
            <strong>Examples:</strong><br /> <br /><tt>/msg GroupServ INFO !baz</tt><br /> <a name="JOIN"><br /> <h2>
              JOIN
            </h2>
            
            <p>
              </a>
            </p>
            
            <p>
              JOIN allows you to join a group set as open for anyone to<br /> join. No privileges will be set on you when you join a group<br /> this way, you will only be listed as a group member.
            </p>
            
            <p>
              <strong>Syntax:</strong> <tt>JOIN <!group></tt>
            </p>
            
            <p>
              <strong>Examples:</strong><br /> <br /><tt>/msg GroupServ JOIN !baz</tt><br /> <a name="LIST"><br /> <h2>
                LIST
              </h2>
              
              <p>
                </a>
              </p>
              
              <p>
                LIST shows all groups matching a specified pattern.
              </p>
              
              <p>
                <strong>Syntax:</strong> <tt>LIST <group pattern></tt>
              </p>
              
              <p>
                <strong>Examples:</strong><br /> <br /><tt>/msg GroupServ LIST *</tt><br /> <br /><tt>/msg GroupServ LIST !pants*</tt><br /> <a name="REGISTER"><br /> <h2>
                  REGISTER
                </h2>
                
                <p>
                  </a>
                </p>
                
                <p>
                  REGISTER allows you to register a group so that you can easily<br /> manage a number of users and channels.
                </p>
                
                <p>
                  <strong>Syntax:</strong> <tt>REGISTER <!group></tt>
                </p>
                
                <p>
                  <strong>Examples:</strong><br /> <br /><tt>/msg GroupServ REGISTER !developers</tt><br /> <a name="REGNOLIMIT"><br /> <h2>
                    REGNOLIMIT
                  </h2>
                  
                  <p>
                    </a>
                  </p>
                  
                  <p>
                    REGNOLIMIT allows a group to collectively maintain an<br /> unlimited amount of channel registrations.
                  </p>
                  
                  <p>
                    <strong>Syntax:</strong> <tt>REGNOLIMIT <!group> ON|OFF</tt>
                  </p>
                  
                  <p>
                    <strong>Examples:</strong><br /> <br /><tt>/msg GroupServ REGNOLIMIT !awesome-people ON</tt><br /> <a name="SET CHANNEL"><br /> <h2>
                      SET CHANNEL
                    </h2>
                    
                    <p>
                      </a>
                    </p>
                    
                    <p>
                      SET CHANNEL allows you to change or set the official IRC channel<br /> of a group. This is shown when a user requests info about the group.
                    </p>
                    
                    <p>
                      <strong>Syntax:</strong> <tt>SET <!group> CHANNEL [#channel]</tt>
                    </p>
                    
                    <p>
                      <strong>Example:</strong><br /> <br /><tt>/msg GroupServ SET !atheme CHANNEL #atheme</tt><br /> <a name="SET DESCRIPTION"><br /> <h2>
                        SET DESCRIPTION
                      </h2>
                      
                      <p>
                        </a>
                      </p>
                      
                      <p>
                        SET DESCRIPTION allows you to change or set the description<br /> of a group. This is shown when a user requests info about<br /> the group.
                      </p>
                      
                      <p>
                        <strong>Syntax:</strong> <tt>SET <!group> DESCRIPTION [description]</tt>
                      </p>
                      
                      <p>
                        <strong>Example:</strong><br /> <br /><tt>/msg GroupServ SET !atheme DESCRIPTION Official Atheme Group</tt><br /> <a name="SET EMAIL"><br /> <h2>
                          SET EMAIL
                        </h2>
                        
                        <p>
                          </a>
                        </p>
                        
                        <p>
                          SET EMAIL allows you to change or set the email<br /> address associated with a group. This is shown<br /> to all users in INFO.
                        </p>
                        
                        <p>
                          <strong>Syntax:</strong> <tt>SET <!group> EMAIL [email]</tt>
                        </p>
                        
                        <p>
                          Using the command in this way results in an email<br /> address being associated with the group.
                        </p>
                        
                        <p>
                          <strong>Example:</strong><br /> <br /><tt>/msg GroupServ SET !bar EMAIL some@email.address</tt>
                        </p>
                        
                        <p>
                          <a name="SET JOINFLAGS"><br /> <h2>
                            SET JOINFLAGS
                          </h2>
                          
                          <p>
                            </a>
                          </p>
                          
                          <p>
                            SET JOINFLAGS allows a group to specify the flags assigned<br /> to a user when they JOIN the group (if the group is open).
                          </p>
                          
                          <p>
                            Note that this must be valid, else &#8220;+&#8221; will be set on joining<br /> users. If no parameter is provided or the parameter is OFF, the<br /> join flags will be returned to network default.
                          </p>
                          
                          <p>
                            See &#8220;/msg GroupServ HELP FLAGS&#8221; for details of the different flags that<br /> are valid here.
                          </p>
                          
                          <p>
                            <strong>Syntax:</strong> <tt>SET <!group> JOINFLAGS [OFF|flags]</tt>
                          </p>
                          
                          <p>
                            <strong>Examples:</strong><br /> <br /><tt>/msg GroupServ SET !awesome-people JOINFLAGS OFF</tt><br /> <br /><tt>/msg GroupServ SET !foo JOINFLAGS +</tt><br /> <br /><tt>/msg GroupServ SET !foo JOINFLAGS +v</tt><br /> <br /><tt>/msg GroupServ SET !foo JOINFLAGS +cfv</tt><br /> <a name="SET OPEN"><br /> <h2>
                              SET OPEN
                            </h2>
                            
                            <p>
                              </a>
                            </p>
                            
                            <p>
                              SET OPEN allows a group to be open to any user joining<br /> whenever they like. Users that JOIN the group will have<br /> no privileges by default.
                            </p>
                            
                            <p>
                              <strong>Syntax:</strong> <tt>SET <!group> OPEN <ON|OFF></tt>
                            </p>
                            
                            <p>
                              <strong>Examples:</strong><br /> <br /><tt>/msg GroupServ SET !awesome-people OPEN ON</tt><br /> <a name="SET PUBLIC"><br /> <h2>
                                SET PUBLIC
                              </h2>
                              
                              <p>
                                </a>
                              </p>
                              
                              <p>
                                SET PUBLIC shows group membership when users request NickServ<br /> INFO of members of the group.
                              </p>
                              
                              <p>
                                <strong>Syntax:</strong> <tt>SET <!group> PUBLIC <ON|OFF></tt>
                              </p>
                              
                              <p>
                                <strong>Examples:</strong><br /> <br /><tt>/msg GroupServ SET !awesome-people PUBLIC ON</tt><br /> <a name="SET URL"><br /> <h2>
                                  SET URL
                                </h2>
                                
                                <p>
                                  </a>
                                </p>
                                
                                <p>
                                  SET URL allows you to change or set the URL<br /> associated with a group. This is shown<br /> to all users in INFO.
                                </p>
                                
                                <p>
                                  <strong>Syntax:</strong> <tt>SET <!group> URL <a href=""></a></tt>
                                </p>
                                
                                <p>
                                  <strong>Example:</strong><br /> <br /><tt>/msg GroupServ SET !slashdot URL http://slashdot.org</tt>
                                </p>