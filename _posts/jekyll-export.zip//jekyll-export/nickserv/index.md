---
title: NickServ
author: MrRandom
layout: page
---
<a name="ACC"><br /> <h2>
  ACC
</h2>

<p>
  </a>
</p>

<p>
  ACC returns parsable information about a user&#8217;s<br /> login status. Note that on many networks, /whois<br /> shows similar information faster and more reliably.<br /> The answer is in the form <nick> ACC <digit>:<br /> <br /><tt>0 - account or user does not exist</tt><br /> <br /><tt>1 - account exists but user is not logged in</tt><br /> <br /><tt>2 - user is not logged in but recognized (see ACCESS)</tt><br /> <br /><tt>3 - user is logged in</tt>
</p>

<p>
  If the account is omitted the user&#8217;s nick is used.<br /> Account * means the account the user is logged in with.
</p>

<p>
  <strong>Syntax:</strong> <tt>ACC</tt><br /> <strong>Syntax:</strong> <tt>ACC <nick></tt><br /> <strong>Syntax:</strong> <tt>ACC <nick> <account></tt><br /> <strong>Syntax:</strong> <tt>ACC <nick> *</tt>
</p>

<p>
  <strong>Example:</strong><br /> <br /><tt>/msg NickServ ACC jilles *</tt><br /> <a name="ACCESS"><br /> <h2>
    ACCESS
  </h2>
  
  <p>
    </a>
  </p>
  
  <p>
    ACCESS maintains a list of user@host masks from where<br /> NickServ will recognize you, so it will not prompt you to<br /> change nick. Preventing expiry, getting channel access<br /> or editing nickname settings still requires<br /> identification, however.
  </p>
  
  <p>
    Access list entries can use hostnames with optional<br /> wildcards, IP addresses and CIDR masks. There are<br /> restrictions on how much you can wildcard. If you omit<br /> the mask, NickServ will attempt to generate one matching<br /> your current connection.
  </p>
  
  <p>
    <strong>Syntax:</strong> <tt>ACCESS LIST</tt><br /> <strong>Syntax:</strong> <tt>ACCESS ADD [mask]</tt><br /> <strong>Syntax:</strong> <tt>ACCESS DEL <mask></tt>
  </p>
  
  <p>
    Operators with user:auspex privilege can also<br /> view another user&#8217;s access list.
  </p>
  
  <p>
    <strong>Syntax:</strong> <tt>ACCESS LIST <nick></tt>
  </p>
  
  <p>
    <strong>Examples:</strong><br /> <br /><tt>/msg NickServ ACCESS LIST</tt><br /> <br /><tt>/msg NickServ ACCESS ADD jack@host.example.com</tt><br /> <br /><tt>/msg NickServ ACCESS ADD user@10.0.0.8</tt><br /> <br /><tt>/msg NickServ ACCESS ADD jilles@192.168.1.0/24</tt><br /> <br /><tt>/msg NickServ ACCESS DEL *someone@*.area.old.example.net</tt><br /> <a name="DROP"><br /> <h2>
      DROP
    </h2>
    
    <p>
      </a>
    </p>
    
    <p>
      Using this command makes NickServ remove your account<br /> and stop watching your nick(s), If a nick is dropped,<br /> anyone else can register it. You will also lose all<br /> your channel access and memos.
    </p>
    
    <p>
      When dropping and re-registering an account during a<br /> netsplit, users on the other side of the split may later<br /> be recognized as the new account.
    </p>
    
    <p>
      <strong>Syntax:</strong> <tt>DROP <nickname> <password></tt>
    </p>
    
    <p>
      <strong>Examples:</strong><br /> <br /><tt>/msg NickServ DROP foo bar</tt><br /> <a name="FDROP"><br /> <h2>
        FDROP
      </h2>
      
      <p>
        </a>
      </p>
      
      <p>
        FDROP forcefully removes the given account, including<br /> all nicknames, channel access and memos attached to it.
      </p>
      
      <p>
        When dropping and re-registering an account during a<br /> netsplit, users on the other side of the split may later<br /> be recognized as the new account.
      </p>
      
      <p>
        <strong>Syntax:</strong> <tt>FDROP <nickname></tt>
      </p>
      
      <p>
        <strong>Examples:</strong><br /> <br /><tt>/msg NickServ FDROP foo</tt><br /> <a name="FREEZE"><br /> <h2>
          FREEZE
        </h2>
        
        <p>
          </a>
        </p>
        
        <p>
          FREEZE allows operators to &#8220;freeze&#8221; an abusive user&#8217;s<br /> account. This logs out all sessions logged in to the<br /> account and prevents further logins. Thus, users<br /> cannot obtain the access associated with the account.
        </p>
        
        <p>
          FREEZE information will be displayed in INFO output.
        </p>
        
        <p>
          <strong>Syntax:</strong> <tt>FREEZE <nick> ON|OFF <reason></tt>
        </p>
        
        <p>
          <strong>Examples:</strong><br /> <br /><tt>/msg NickServ FREEZE pfish ON Persistent spammer</tt><br /> <br /><tt>/msg NickServ FREEZE alambert OFF</tt><br /> <a name="FUNGROUP"><br /> <h2>
            FUNGROUP
          </h2>
          
          <p>
            </a>
          </p>
          
          <p>
            FUNGROUP forcefully unregisters the given nickname<br /> from the account it is registered to.
          </p>
          
          <p>
            If you are ungrouping an account name, you need to<br /> specify a new name for the account. This must be<br /> another nick registered to it.<br /> You cannot ungroup account names.
          </p>
          
          <p>
            <strong>Syntax:</strong> <tt>FUNGROUP <nickname></tt><br /> <strong>Syntax:</strong> <tt>FUNGROUP <account> <newname></tt>
          </p>
          
          <p>
            <strong>Examples:</strong><br /> <br /><tt>/msg NickServ FUNGROUP SomeNick</tt><br /> <br /><tt>/msg NickServ FUNGROUP SomeName SomeNick</tt><br /> <a name="GHOST"><br /> <h2>
              GHOST
            </h2>
            
            <p>
              </a>
            </p>
            
            <p>
              GHOST disconnects an old user session, or somebody<br /> attempting to use your nickname without authorization.
            </p>
            
            <p>
              If you are logged in to the nick&#8217;s account, you need<br /> not specify a password, otherwise you have to.
            </p>
            
            <p>
              <strong>Syntax:</strong> <tt>GHOST <nick> [password]</tt>
            </p>
            
            <p>
              <strong>Example:</strong><br /> <br /><tt>/msg NickServ GHOST foo bar</tt><br /> <a name="GROUP"><br /> <h2>
                GROUP
              </h2>
              
              <p>
                </a>
              </p>
              
              <p>
                GROUP registers your current nickname to your account.<br /> This means that NickServ protects this nickname the<br /> same way as it protects your account name. Most<br /> services commands will accept the new nickname as<br /> an alias for your account name.
              </p>
              
              <p>
                Please note that grouped nicks expire separately<br /> from accounts. To prevent this, you must use them.<br /> Otherwise, all properties of the account are shared<br /> among all nicks registered to it.
              </p>
              
              <p>
                <strong>Syntax:</strong> <tt>GROUP</tt>
              </p>
              
              <p>
                <strong>Examples:</strong><br /> <br /><tt>/msg NickServ IDENTIFY OldNick SecretPassword</tt><br /> <br /><tt>/msg NickServ GROUP</tt><br /> <a name="HOLD"><br /> <h2>
                  HOLD
                </h2>
                
                <p>
                  </a>
                </p>
                
                <p>
                  HOLD prevents an account and all nicknames registered<br /> to it from expiring.
                </p>
                
                <p>
                  <strong>Syntax:</strong> <tt>HOLD <nick> ON|OFF</tt>
                </p>
                
                <p>
                  <strong>Examples:</strong><br /> <br /><tt>/msg NickServ HOLD jilles ON</tt><br /> <a name="IDENTIFY"><br /> <h2>
                    IDENTIFY
                  </h2>
                  
                  <p>
                    </a>
                  </p>
                  
                  <p>
                    IDENTIFY identifies you with services so that you<br /> can perform general maintenance and commands that<br /> require you to be logged in.
                  </p>
                  
                  <p>
                    <strong>Syntax:</strong> <tt>IDENTIFY <password></tt>
                  </p>
                  
                  <p>
                    You can also identify for another nick than you<br /> are currently using.
                  </p>
                  
                  <p>
                    <strong>Syntax:</strong> <tt>IDENTIFY <nick> <password></tt>
                  </p>
                  
                  <p>
                    <strong>Example:</strong><br /> <br /><tt>/msg NickServ IDENTIFY foo</tt><br /> <br /><tt>/msg NickServ IDENTIFY jilles foo</tt><br /> <a name="INFO"><br /> <h2>
                      INFO
                    </h2>
                    
                    <p>
                      </a>
                    </p>
                    
                    <p>
                      INFO displays account information such as<br /> registration time, flags, and other details.<br /> Additionally it will display registration<br /> and last seen time of the nick you give.
                    </p>
                    
                    <p>
                      You can query the nick a user is logged in as<br /> by specifying an equals sign followed by their<br /> nick. This &#8216;=&#8217; convention works with most commands.
                    </p>
                    
                    <p>
                      <strong>Syntax:</strong> <tt>INFO <nickname></tt><br /> <strong>Syntax:</strong> <tt>INFO =<online user></tt>
                    </p>
                    
                    <p>
                      <strong>Examples:</strong><br /> <br /><tt>/msg NickServ INFO w00t</tt><br /> Shows information about the registered nick w00t.<br /> <br /><tt>/msg NickServ INFO =w00tie[home]</tt><br /> Shows information about the registered nick the user<br /> w00tie[home] is logged in as.<br /> <a name="LIST"><br /> <h2>
                        LIST
                      </h2>
                      
                      <p>
                        </a>
                      </p>
                      
                      <p>
                        LIST shows registered users that match a given criteria.<br /> Multiple criteria may be used in the same command.
                      </p>
                      
                      <p>
                        Current Criteria are:<br /> PATTERN &#8211; All users that match a given pattern.<br /> EMAIL &#8211; All accounts registered with an email address<br /> <br /><tt> that matches a given pattern.</tt><br /> MARK-REASON &#8211; All accounts whose mark reason matches a<br /> <br /><tt> given pattern.</tt><br /> FROZEN-REASON &#8211; All frozen accounts whose freeze reason matches<br /> <br /><tt> a given pattern.</tt><br /> HOLD &#8211; All users with the HOLD flag set.<br /> NOOP &#8211; All users with the NOOP flag set.<br /> NEVEROP &#8211; All users with the NEVEROP flag set.<br /> WAITAUTH &#8211; All users with the WAITAUTH flag set.<br /> HIDEMAIL &#8211; All users with the HIDEMAIL flag set.<br /> NOMEMO &#8211; All users with the NOMEMO flag set.<br /> EMAILMEMOS &#8211; All users with the EMAILMEMOS flag set.<br /> USE-PRIVMSG &#8211; All users with the USEPRIVMSG flag set.<br /> QUIETCHG &#8211; All users with the QUIETCHG flag set.<br /> NOGREET &#8211; All users with the NOGREET flag set.<br /> PRIVATE &#8211; All users with the PRIVATE flag set.<br /> REGNOLIMIT &#8211; All users with the REGNOLIMIT flag set.
                      </p>
                      
                      <p>
                        FROZEN &#8211; All users frozen by network staff.<br /> MARKED &#8211; All users marked by network staff.<br /> REGISTERED &#8211; User accounts registered longer ago than a given age.<br /> LASTUSED &#8211; User accounts last used longer ago than a given age.
                      </p>
                      
                      <p>
                        <strong>Syntax:</strong> <tt>LIST <criteria></tt>
                      </p>
                      
                      <p>
                        <strong>Examples:</strong><br /> <br /><tt>/msg NickServ LIST pattern foo*</tt><br /> <br /><tt>/msg NickServ LIST hold</tt><br /> <br /><tt>/msg NickServ LIST frozen pattern x*</tt><br /> <br /><tt>/msg NickServ LIST registered 30d</tt><br /> <br /><tt>/msg NickServ LIST marked registered 7d pattern bar</tt><br /> <br /><tt>/msg NickServ LIST email *@gmail.com</tt><br /> <br /><tt>/msg NickServ LIST mark-reason *lamer*</tt><br /> <a name="LISTCHANS"><br /> <h2>
                          LISTCHANS
                        </h2>
                        
                        <p>
                          </a>
                        </p>
                        
                        <p>
                          LISTCHANS shows the channels that you have access<br /> to, including those that you own.
                        </p>
                        
                        <p>
                          AKICKs and host-based access are not shown.
                        </p>
                        
                        <p>
                          <strong>Syntax:</strong> <tt>LISTCHANS</tt>
                        </p>
                        
                        <p>
                          Operators with chan:auspex privilege can also<br /> check another user&#8217;s access.
                        </p>
                        
                        <p>
                          <strong>Syntax:</strong> <tt>LISTCHANS <nick></tt>
                        </p>
                        
                        <p>
                          <strong>Example:</strong><br /> <br /><tt>/msg NickServ LISTCHANS</tt><br /> <a name="LISTVHOST"><br /> <h2>
                            LISTVHOST
                          </h2>
                          
                          <p>
                            </a>
                          </p>
                          
                          <p>
                            LISTVHOST shows accounts which have a vhost set<br /> on them. If a pattern is given, only accounts<br /> with vhosts matching the pattern are shown.
                          </p>
                          
                          <p>
                            <strong>Syntax:</strong> <tt>LISTVHOST [pattern]</tt>
                          </p>
                          
                          <p>
                            <strong>Examples:</strong><br /> <br /><tt>/msg NickServ LISTVHOST</tt><br /> <br /><tt>/msg NickServ LISTVHOST *staff*</tt><br /> <a name="LOGIN"><br /> <h2>
                              LOGIN
                            </h2>
                            
                            <p>
                              </a>
                            </p>
                            
                            <p>
                              LOGIN identifies you with services so that you<br /> can perform general maintenance and commands that<br /> require you to be logged in.
                            </p>
                            
                            <p>
                              <strong>Syntax:</strong> <tt>LOGIN <account> <password></tt>
                            </p>
                            
                            <p>
                              <strong>Example:</strong><br /> <br /><tt>/msg NickServ LOGIN smith sesame</tt><br /> <a name="LOGOUT"><br /> <h2>
                                LOGOUT
                              </h2>
                              
                              <p>
                                </a>
                              </p>
                              
                              <p>
                                LOGOUT logs you out of the account<br /> that you are currently logged into.
                              </p>
                              
                              <p>
                                <strong>Syntax:</strong> <tt>LOGOUT</tt>
                              </p>
                              
                              <p>
                                <strong>Example:</strong><br /> <br /><tt>/msg NickServ LOGOUT</tt><br /> <a name="MARK"><br /> <h2>
                                  MARK
                                </h2>
                                
                                <p>
                                  </a>
                                </p>
                                
                                <p>
                                  MARK allows operators to attach a note to an account.<br /> For example, an operator could mark the account of<br /> a spammer so that others know the user has previously<br /> been warned.
                                </p>
                                
                                <p>
                                  MARK information will be displayed in INFO output.
                                </p>
                                
                                <p>
                                  <strong>Syntax:</strong> <tt>MARK <nickname> ON|OFF <reason></tt>
                                </p>
                                
                                <p>
                                  <strong>Examples:</strong><br /> <br /><tt>/msg NickServ MARK game_boy ON Persistent spammer</tt><br /> <br /><tt>/msg NickServ MARK nenolod OFF</tt><br /> <a name="REGAIN"><br /> <h2>
                                    REGAIN
                                  </h2>
                                  
                                  <p>
                                    </a>
                                  </p>
                                  
                                  <p>
                                    REGAIN regains access to your nickname from<br /> a user that is using your nick.
                                  </p>
                                  
                                  <p>
                                    If you are logged in to the account associated with<br /> the nickname, you need not specify a password,<br /> otherwise you have to.
                                  </p>
                                  
                                  <p>
                                    <strong>Syntax:</strong> <tt>REGAIN <nick> [password]</tt>
                                  </p>
                                  
                                  <p>
                                    <strong>Example:</strong><br /> <br /><tt>/msg NickServ REGAIN Dave2 goats</tt><br /> <a name="REGISTER"><br /> <h2>
                                      REGISTER
                                    </h2>
                                    
                                    <p>
                                      </a>
                                    </p>
                                    
                                    <p>
                                      This will register your current nickname with NickServ.<br /> This will allow you to assert some form of identity on<br /> the network and to be added to access lists. Furthermore,<br /> NickServ will warn users using your nick without<br /> identifying and allow you to kill ghosts.<br /> The password is a case-sensitive password that you make<br /> up. Please write down or memorize your password! You<br /> will need it later to change settings.
                                    </p>
                                    
                                    <p>
                                      You have to confirm the email address. To do this,<br /> follow the instructions in the message sent to the email<br /> address.
                                    </p>
                                    
                                    <p>
                                      <strong>Syntax:</strong> <tt>REGISTER <password> <email-address></tt>
                                    </p>
                                    
                                    <p>
                                      <strong>Examples:</strong><br /> <br /><tt>/msg NickServ REGISTER bar foo@bar.com</tt><br /> <a name="REGNOLIMIT"><br /> <h2>
                                        REGNOLIMIT
                                      </h2>
                                      
                                      <p>
                                        </a>
                                      </p>
                                      
                                      <p>
                                        REGNOLIMIT allows a user to maintain an<br /> unlimited amount of channel registrations.
                                      </p>
                                      
                                      <p>
                                        <strong>Syntax:</strong> <tt>REGNOLIMIT <user> ON|OFF</tt>
                                      </p>
                                      
                                      <p>
                                        <strong>Examples:</strong><br /> <br /><tt>/msg NickServ REGNOLIMIT nenolod ON</tt><br /> <a name="RELEASE"><br /> <h2>
                                          RELEASE
                                        </h2>
                                        
                                        <p>
                                          </a>
                                        </p>
                                        
                                        <p>
                                          RELEASE removes an enforcer for your nick or<br /> changes the nick of a user that is using your<br /> nick.
                                        </p>
                                        
                                        <p>
                                          Enforcers are created when someone uses your<br /> nick without identifying and prevent all use<br /> of it.
                                        </p>
                                        
                                        <p>
                                          If you are logged in to the nick, you need not specify<br /> a password, otherwise you have to.
                                        </p>
                                        
                                        <p>
                                          <strong>Syntax:</strong> <tt>RELEASE <nick> [password]</tt>
                                        </p>
                                        
                                        <p>
                                          <strong>Example:</strong><br /> <br /><tt>/msg NickServ RELEASE smith sesame</tt><br /> <a name="RESETPASS"><br /> <h2>
                                            RESETPASS
                                          </h2>
                                          
                                          <p>
                                            </a>
                                          </p>
                                          
                                          <p>
                                            RESETPASS sets a random password for the specified<br /> account.
                                          </p>
                                          
                                          <p>
                                            <strong>Syntax:</strong> <tt>RESETPASS <nickname></tt>
                                          </p>
                                          
                                          <p>
                                            <strong>Examples:</strong><br /> <br /><tt>/msg NickServ RESETPASS pfish</tt><br /> <a name="RESTRICT"><br /> <h2>
                                              RESTRICT
                                            </h2>
                                            
                                            <p>
                                              </a>
                                            </p>
                                            
                                            <p>
                                              RESTRICT allows operators to restrict what an account can and can not do.<br /> It will currently block a user from grouping nicks, registering a channel,<br /> requesting a vhost or taking an OFFERed vhost.
                                            </p>
                                            
                                            <p>
                                              This is particularly useful if a user starts abusing these commands.
                                            </p>
                                            
                                            <p>
                                              <strong>Syntax:</strong> <tt>RESTRICT <nickname> ON|OFF <reason></tt>
                                            </p>
                                            
                                            <p>
                                              <strong>Examples:</strong><br /> <br /><tt>/msg NickServ RESTRICT game_boy ON Abusing vhost requests</tt><br /> <br /><tt>/msg NickServ RESTRICT nenolod OFF</tt><br /> <a name="RETURN"><br /> <h2>
                                                RETURN
                                              </h2>
                                              
                                              <p>
                                                </a>
                                              </p>
                                              
                                              <p>
                                                RETURN resets the specified account<br /> password, sends it to the email address<br /> specified and changes account&#8217;s email address<br /> to this address. Any current sessions logged<br /> in to the account are logged out.
                                              </p>
                                              
                                              <p>
                                                <strong>Syntax:</strong> <tt>RETURN <nickname> <e-mail></tt>
                                              </p>
                                              
                                              <p>
                                                <strong>Examples:</strong><br /> <br /><tt>/msg NickServ RETURN jdoe john@example.com</tt><br /> <a name="SENDPASS"><br /> <h2>
                                                  SENDPASS
                                                </h2>
                                                
                                                <p>
                                                  </a>
                                                </p>
                                                
                                                <p>
                                                  SENDPASS emails the password for the specified<br /> nickname to the corresponding email address.<br /> SENDPASS emails a key to the email address<br /> corresponding to the specified nickname<br /> that can be used to set a new password<br /> using SETPASS.
                                                </p>
                                                
                                                <p>
                                                  <strong>Syntax:</strong> <tt>SENDPASS <nickname></tt>
                                                </p>
                                                
                                                <p>
                                                  If the nickname is marked, you can override this<br /> using the FORCE keyword.
                                                </p>
                                                
                                                <p>
                                                  <strong>Syntax:</strong> <tt>SENDPASS <nickname> FORCE</tt>
                                                </p>
                                                
                                                <p>
                                                  If a key has been emailed but not yet used,<br /> you can clear it using the CLEAR keyword.
                                                </p>
                                                
                                                <p>
                                                  <strong>Syntax:</strong> <tt>SENDPASS <nickname> CLEAR</tt>
                                                </p>
                                                
                                                <p>
                                                  <strong>Examples:</strong><br /> <br /><tt>/msg NickServ SENDPASS foo</tt><br /> <a name="SENDPASS"><br /> <h2>
                                                    SENDPASS
                                                  </h2>
                                                  
                                                  <p>
                                                    </a>
                                                  </p>
                                                  
                                                  <p>
                                                    SENDPASS emails a key to the email address<br /> corresponding to the specified nickname<br /> that can be used to set a new password<br /> using SETPASS.
                                                  </p>
                                                  
                                                  <p>
                                                    <strong>Syntax:</strong> <tt>SENDPASS <nickname></tt>
                                                  </p>
                                                  
                                                  <p>
                                                    If a key has been emailed but not yet used,<br /> you can clear it using the CLEAR keyword.
                                                  </p>
                                                  
                                                  <p>
                                                    <strong>Syntax:</strong> <tt>SENDPASS <nickname> CLEAR</tt>
                                                  </p>
                                                  
                                                  <p>
                                                    <strong>Examples:</strong><br /> <br /><tt>/msg NickServ SENDPASS foo</tt><br /> <a name="SET EMAIL"><br /> <h2>
                                                      SET EMAIL
                                                    </h2>
                                                    
                                                    <p>
                                                      </a>
                                                    </p>
                                                    
                                                    <p>
                                                      SET EMAIL changes the e-mail address<br /> associated with an account. The e-mail<br /> address is used for password retrieval.
                                                    </p>
                                                    
                                                    <p>
                                                      You may be required to confirm the new<br /> e-mail address. To confirm the address,<br /> follow the instructions in the message<br /> sent to the new address.
                                                    </p>
                                                    
                                                    <p>
                                                      <strong>Syntax:</strong> <tt>SET EMAIL <new address></tt>
                                                    </p>
                                                    
                                                    <p>
                                                      <strong>Example:</strong><br /> <br /><tt>/msg NickServ SET EMAIL dan@example.com</tt><br /> <a name="SET ENFORCE"><br /> <h2>
                                                        SET ENFORCE
                                                      </h2>
                                                      
                                                      <p>
                                                        </a>
                                                      </p>
                                                      
                                                      <p>
                                                        SET ENFORCE allows you to enable more protection for<br /> all nicknames registered to your account.
                                                      </p>
                                                      
                                                      <p>
                                                        This will automatically change the nick of someone<br /> who attempts to use it without identifying in time,<br /> and temporarily block its use, which can be<br /> removed at your discretion. See help on RELEASE.
                                                      </p>
                                                      
                                                      <p>
                                                        <strong>Syntax:</strong> <tt>SET ENFORCE ON|OFF</tt><br /> <a name="SET HIDEMAIL"><br /> <h2>
                                                          SET HIDEMAIL
                                                        </h2>
                                                        
                                                        <p>
                                                          </a>
                                                        </p>
                                                        
                                                        <p>
                                                          SET HIDEMAIL prevents an account&#8217;s e-mail address<br /> from being shown to other users.
                                                        </p>
                                                        
                                                        <p>
                                                          <strong>Syntax:</strong> <tt>SET HIDEMAIL ON|OFF</tt>
                                                        </p>
                                                        
                                                        <p>
                                                          <strong>Example:</strong><br /> <br /><tt>/msg NickServ SET HIDEMAIL ON</tt><br /> <a name="SET LANGUAGE"><br /> <h2>
                                                            SET LANGUAGE
                                                          </h2>
                                                          
                                                          <p>
                                                            </a>
                                                          </p>
                                                          
                                                          <p>
                                                            SET LANGUAGE changes the language services<br /> uses to communicate with you.
                                                          </p>
                                                          
                                                          <p>
                                                            <strong>Syntax:</strong> <tt>SET LANGUAGE <abbreviation></tt>
                                                          </p>
                                                          
                                                          <p>
                                                            <strong>Example:</strong><br /> <br /><tt>/msg NickServ SET LANGUAGE en</tt><br /> <br /><tt>/msg NickServ SET LANGUAGE ru</tt><br /> <a name="SET NEVEROP"><br /> <h2>
                                                              SET NEVEROP
                                                            </h2>
                                                            
                                                            <p>
                                                              </a>
                                                            </p>
                                                            
                                                            <p>
                                                              SET NEVEROP prevents others from adding you to<br /> channel access lists.
                                                            </p>
                                                            
                                                            <p>
                                                              <strong>Syntax:</strong> <tt>SET NEVEROP ON|OFF</tt>
                                                            </p>
                                                            
                                                            <p>
                                                              <strong>Example:</strong><br /> <br /><tt>/msg NickServ SET NEVEROP ON</tt><br /> <a name="SET NOMEMO"><br /> <h2>
                                                                SET NOMEMO
                                                              </h2>
                                                              
                                                              <p>
                                                                </a>
                                                              </p>
                                                              
                                                              <p>
                                                                This prevents people from being able to send you<br /> a memo. If you do not want to receive memos, you<br /> can just turn them off for your nick.
                                                              </p>
                                                              
                                                              <p>
                                                                <strong>Syntax:</strong> <tt>SET NOMEMO ON|OFF</tt>
                                                              </p>
                                                              
                                                              <p>
                                                                <strong>Example:</strong><br /> <br /><tt>/msg NickServ SET NOMEMO ON</tt><br /> <a name="SET NOOP"><br /> <h2>
                                                                  SET NOOP
                                                                </h2>
                                                                
                                                                <p>
                                                                  </a>
                                                                </p>
                                                                
                                                                <p>
                                                                  SET NOOP prevents services from automatically<br /> opping you in channels you have access in.<br /> You can choose to op/voice yourself by using<br /> the OP and VOICE commands.
                                                                </p>
                                                                
                                                                <p>
                                                                  <strong>Syntax:</strong> <tt>SET NOOP ON|OFF</tt>
                                                                </p>
                                                                
                                                                <p>
                                                                  <strong>Example:</strong><br /> <br /><tt>/msg NickServ SET NOOP ON</tt><br /> <a name="SET PASSWORD"><br /> <h2>
                                                                    SET PASSWORD
                                                                  </h2>
                                                                  
                                                                  <p>
                                                                    </a>
                                                                  </p>
                                                                  
                                                                  <p>
                                                                    SET PASSWORD changes the password of an account.
                                                                  </p>
                                                                  
                                                                  <p>
                                                                    <strong>Syntax:</strong> <tt>SET PASSWORD <new password></tt>
                                                                  </p>
                                                                  
                                                                  <p>
                                                                    <strong>Example:</strong><br /> <br /><tt>/msg NickServ SET PASSWORD swordfish</tt><br /> <a name="SET PRIVATE"><br /> <h2>
                                                                      SET PRIVATE
                                                                    </h2>
                                                                    
                                                                    <p>
                                                                      </a>
                                                                    </p>
                                                                    
                                                                    <p>
                                                                      SET PRIVATE hides various information about your<br /> account from other users.
                                                                    </p>
                                                                    
                                                                    <p>
                                                                      SET PRIVATE ON automatically enables HIDEMAIL too.
                                                                    </p>
                                                                    
                                                                    <p>
                                                                      <strong>Syntax:</strong> <tt>SET PRIVATE ON|OFF</tt>
                                                                    </p>
                                                                    
                                                                    <p>
                                                                      <strong>Example:</strong><br /> <br /><tt>/msg NickServ SET PRIVATE ON</tt><br /> <a name="SET QUIETCHG"><br /> <h2>
                                                                        SET QUIETCHG
                                                                      </h2>
                                                                      
                                                                      <p>
                                                                        </a>
                                                                      </p>
                                                                      
                                                                      <p>
                                                                        SET QUIETCHG prevents services from automatically<br /> notifying you when ChanServ is used to affect your<br /> status in channels. When set to ON, Services will no<br /> longer send you messages of this nature.
                                                                      </p>
                                                                      
                                                                      <p>
                                                                        <strong>Syntax:</strong> <tt>SET QUIETCHG ON|OFF</tt>
                                                                      </p>
                                                                      
                                                                      <p>
                                                                        <strong>Example:</strong><br /> <br /><tt>/msg NickServ SET QUIETCHG ON</tt><br /> <a name="SETPASS"><br /> <h2>
                                                                          SETPASS
                                                                        </h2>
                                                                        
                                                                        <p>
                                                                          </a>
                                                                        </p>
                                                                        
                                                                        <p>
                                                                          SETPASS allows you to set a new password<br /> using a key emailed to you. The key is<br /> valid for one time only, and also becomes<br /> invalid if you identify with your old password.
                                                                        </p>
                                                                        
                                                                        <p>
                                                                          To set a new password if you know the current<br /> password, use SET PASSWORD instead of SETPASS.
                                                                        </p>
                                                                        
                                                                        <p>
                                                                          <strong>Syntax:</strong> <tt>SETPASS <nickname> <key> <password></tt><br /> <a name="STATUS"><br /> <h2>
                                                                            STATUS
                                                                          </h2>
                                                                          
                                                                          <p>
                                                                            </a>
                                                                          </p>
                                                                          
                                                                          <p>
                                                                            STATUS returns information about your current<br /> state. It will show information about your<br /> nickname, IRC operator, and SRA status.
                                                                          </p>
                                                                          
                                                                          <p>
                                                                            <strong>Syntax:</strong> <tt>STATUS</tt>
                                                                          </p>
                                                                          
                                                                          <p>
                                                                            <strong>Example:</strong><br /> <br /><tt>/msg NickServ STATUS</tt><br /> <a name="UNGROUP"><br /> <h2>
                                                                              UNGROUP
                                                                            </h2>
                                                                            
                                                                            <p>
                                                                              </a>
                                                                            </p>
                                                                            
                                                                            <p>
                                                                              UNGROUP unregisters the given nickname from your<br /> account. The nickname will be available for others to<br /> register. This will not affect your channel access<br /> or memos.
                                                                            </p>
                                                                            
                                                                            <p>
                                                                              If you do not specify a nickname, your current<br /> nickname will be ungrouped. You cannot ungroup<br /> your account name.
                                                                            </p>
                                                                            
                                                                            <p>
                                                                              <strong>Syntax:</strong> <tt>UNGROUP [nickname]</tt>
                                                                            </p>
                                                                            
                                                                            <p>
                                                                              <strong>Examples:</strong><br /> <br /><tt>/msg NickServ UNGROUP SomeNick</tt><br /> <a name="VHOST"><br /> <h2>
                                                                                VHOST
                                                                              </h2>
                                                                              
                                                                              <p>
                                                                                </a>
                                                                              </p>
                                                                              
                                                                              <p>
                                                                                VHOST allows operators to set a virtual host (also<br /> known as a spoof or cloak) on an account. This vhost<br /> will be set on the user immediately and each time<br /> they identify.
                                                                              </p>
                                                                              
                                                                              <p>
                                                                                <strong>Syntax:</strong> <tt>VHOST <nickname> ON <vhost></tt><br /> <strong>Syntax:</strong> <tt>VHOST <nickname> OFF</tt>
                                                                              </p>
                                                                              
                                                                              <p>
                                                                                If the nickname is marked, you can override this<br /> using the FORCE keyword.
                                                                              </p>
                                                                              
                                                                              <p>
                                                                                <strong>Syntax:</strong> <tt>VHOST <nickname> ON <vhost> FORCE</tt><br /> <strong>Syntax:</strong> <tt>VHOST <nickname> OFF FORCE</tt>
                                                                              </p>
                                                                              
                                                                              <p>
                                                                                <strong>Examples:</strong><br /> <br /><tt>/msg NickServ VHOST spb ON may.explode.on.impact</tt><br /> <br /><tt>/msg NickServ VHOST nenolod OFF</tt>
                                                                              </p>