---
title: Modes
author: MrRandom
layout: page
---
<h1 style="text-align: center;">
  Channel Modes
</h1>

This section lists all of the possible channel modes that may be used with /MODE

An example of the use of this command is: /mode #chills +o Brigitte

a = Gives Channel Admin to the user  
A = Server/Net Admin only channel (settable by Admins)  
b = Bans the nick!ident@host from the channel.  
Extended bantypes are also available.[h]  
c = Block messages containing mIRC color codes [o]  
C = No CTCPs allowed in the channel [o]  
e = Overrides a ban for matching users [h]  
f = Flood protection ([Check here for info in the IRCd Documentation][1]) [o]  
G = Filters out all Bad words in messages with [o]  
h = Gives HalfOp status to the user (Limited op access)  
i = A user must be invited to join the channel [h]  
I = Overrides +i for matching users [h]  
j = Throttle joins per-user to ‘joins’ per ‘sec’ seconds [o]  
k = Users must specify to join [h]  
K = /KNOCK is not allowed [o]  
l = Channel may hold at most of users [o]  
L = Channel link (If +l is full, the next user will auto-join ) [q]  
m = Moderated channel (only +vhoaq users may speak) [h]  
M = Must be using a registered nick (+r), or have voice access to talk [o]  
n = Users outside the channel can not send PRIVMSGs to the channel [h]  
N = No Nickname changes are permitted in the channel [o]  
o = Gives Operator status to the user  
O = IRC Operator only channel (settable by IRCops)  
p = Private channel [o]  
q = Gives Owner status to the user  
Q = No kicks allowed [o]  
r = The channel is registered (settable by services only)  
R = Only registered (+r) users may join the channel [o]  
s = Secret channel [o]  
S = Strips mIRC color codes [o]  
t = Only +hoaq may change the topic [h]  
T = No NOTICEs allowed in the channel [o]  
u = Auditorium mode (/names and /who #channel only show channel ops) [q]  
U = Block messages containing mIRC formatting codes [o]  
v = Gives Voice to the user (May talk if chan is +m)  
V = /INVITE is not allowed [o]  
z = Only Clients on a Secure Connection (SSL) can join [o]

#### Key

[h] requires at least halfop, [o] requires at least chanop, [q] requires owner

&nbsp;

<h1 style="text-align: center;">
  User Modes
</h1>

Here is a list of all the user modes which are available for use. An example command for setting a mode on yourself is: /umode +D or /mode nickname +D

a = Is a Services Administrator (IRC Operators only)  
A = Is a Server Administrator (IRC Operators only)  
B = Marks you as being a Bot  
C = Is a Co Administrator (IRC Operators only)  
d = Makes it so you can not receive channel PRIVMSGs (Deaf)  
D = Makes it so you cannot receive private PRIVMSGs (Deaf to PMs)  
g = Can read & send to GlobOps, and LocOps  
G = Filters out all Bad words in your messages with <censored>  
h = Available for Help (Help Operator)  
H = Hide IRCop status in /WHO and /WHOIS. (IRC Operators only)  
i = Invisible (Not shown in /WHO searches (This mode CANNOT be unset for your protection))  
N = Is a Network Administrator (IRC Operators only)  
o = Global IRC Operator (IRC Operators only)  
O = Local IRC Operator (IRC Operators only)  
p = Hide all channels in /whois and /who  
q = Only U:lines can kick you (Services Admins/Net Admins only)  
r = Identifies the nick as being Registered (settable by services only)  
R = Allows you to only receive PRIVMSGs/NOTICEs from registered (+r) users  
s = Can listen to Server notices  
S = For Services only. (Protects them)  
t = Says that you are using a /VHOST  
T = Prevents you from receiving CTCPs  
v = Receive infected DCC send rejection notices  
V = Marks the client as a WebTV user  
w = Can listen to Wallop messages  
W = Lets you see when people do a /WHOIS on you (IRC Operators only)  
x= Gives the user a hidden hostname (This mode CANNOT be unset for your protection)  
z = Marks the client as being on a Secure Connection (Can only be set by a server on connect)

 [1]: http://www.unrealircd.com/files/docs/unreal32docs.html#feature_antiflood "UnrealIRCd Documentation"