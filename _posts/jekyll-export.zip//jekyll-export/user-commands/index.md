---
title: User Commands
author: MrRandom
layout: page
---
*   **NICK** 
    <pre> <em>Syntax:</em> /NICK <span style="text-decoration: underline;">newnickname</span>

 Changes your online nick name. Alerts others to the
 change of your nick</pre>

*   <a name="WHOIS"></a>**WHOIS** 
    <pre> <em>Syntax:</em> /WHOIS <span style="text-decoration: underline;">nick</span>

 Displays information of user requested. Includes Full
 Name, Host, Channels User is in, and Oper Status</pre>

*   <a name="WHO"></a>**WHO** 
    <pre> <em>Syntax:</em> /WHO <span style="text-decoration: underline;">mask</span>

 Who allows you to search for users. Masks include:
 nickname, #channel, hostmask (*.attbi.com)</pre>

*   <a name="WHOWAS"></a>**WHOWAS** 
    <pre> <em>Syntax:</em> /WHOWAS <span style="text-decoration: underline;">nick</span> <span style="text-decoration: underline;">maxreplies</span>

 Displays information on a nick that has logged off. The
 &lt;max replies&gt; field is optional, and limits how
 many records will be returned.</pre>

*   <a name="ISON"></a>**ISON** 
    <pre> <em>Syntax:</em> /ISON <span style="text-decoration: underline;">nick1 nick2 nick3 ...</span>

 Allows you to check the online status of a user, or a
 list of users. Simple return, best used for scripts</pre>

*   <a name="JOIN"></a>**JOIN** 
    <pre> <em>Syntax:</em> /JOIN <span style="text-decoration: underline;">channel1,channel2, ...</span>

 Allows you to join channels. Using the /join
 #channel1,#channel2,#channel3 will allow you to join
 more than one channel at a time. The /join 0 command
 makes you PART all channels.</pre>

*   <a name="CYCLE"></a>**CYCLE** 
    <pre> <em>Syntax:</em> /CYCLE <span style="text-decoration: underline;">channel1, channel2, ...</span>

 Cycles the given channel(s). This command is equivalent
      to sending a PART then a JOIN command.</pre>

*   <a name="MOTD"></a>**MOTD** 
    <pre> <em>Syntax:</em> /MOTD <span style="text-decoration: underline;">server</span>

 Displays the servers motd. Adding a server name allows
 you to view motd’s on other servers.</pre>

*   <a name="RULES"></a>**RULES** 
    <pre> <em>Syntax:</em> /RULES <span style="text-decoration: underline;">server</span>

 Displays the ircd.rules of a server. Adding a server
 name allows you to view rules on other servers</pre>

*   <a name="LUSERS"></a>**LUSERS** 
    <pre> <em>Syntax:</em> /LUSERS <span style="text-decoration: underline;">server</span>

 Displays current & max user loads, both global and
 local. Adding a server name   allows you to view the
 statistics from other servers.</pre>

*   <a name="MAP"></a>**MAP** 
    <pre> <em>Syntax:</em> /MAP

 Displays a network map</pre>

*   <a name="QUIT"></a>**QUIT** 
    <pre> <em>Syntax:</em> /QUIT <span style="text-decoration: underline;">reason</span>

 Causes you to disconnect from the server. If you
 include a reason, it will be displayed on all channels
 as you quit</pre>

*   <a name="PING"></a>**PING** 
    <pre> <em>Syntax:</em> /PING <span style="text-decoration: underline;">user</span>

 Sends a PING request to a user. Used for checking
 connection and lag. Servers issue pings on a timed
 basis to determine if users are still connected.</pre>

*   <a name="VERISON"></a>**VERSION** 
    <pre> <em>Syntax:</em> /VERSION <span style="text-decoration: underline;">server</span>

 Shows you the version of the IRCd and other
 info related to it. If you specify a server, you
 will be shown information relating to that server</pre>

*   <a name="LINKS"></a>**LINKS** 
    <pre> <em>Syntax:</em> /LINKS

 Displays a list of all servers linked to the network</pre>

*   <a name="ADMIN"></a>**ADMIN** 
    <pre> <em>Syntax:</em> /ADMIN <span style="text-decoration: underline;">server</span>

 Displays the admin info of a server. If a server name
 is included it will display the info of that server.</pre>

*   <a name="USERHOST"></a>**USERHOST** 
    <pre> <em>Syntax:</em> /USERHOST <span style="text-decoration: underline;">nick</span>

 Displays the userhost of the nick given. Generally used
 for scripts</pre>

*   <a name="TOPIC"></a>**TOPIC** 
    <pre> <em>Syntax:</em> /TOPIC <span style="text-decoration: underline;">channel</span> <span style="text-decoration: underline;">topic</span>

 Topic &lt;channel&gt; will display the current topic of
 the given channel. Topic &lt;channel&gt; &lt;topic&gt;
 will change the topic of the given channel.</pre>

*   <a name="AWAY"></a>**AWAY** 
    <pre> <em>Syntax:</em> /AWAY <span style="text-decoration: underline;">reason</span>

 Marks you as being away. A reason may also be supplied.</pre>

*   <a name="WATCH"></a>**WATCH** 
    <pre> <em>Syntax:</em> /WATCH +-<span style="text-decoration: underline;">nick</span> +-<span style="text-decoration: underline;">nick</span>

 Watch is a new notify-type system in UnrealIRCd which
 is both faster and uses less network resources than any
 old-style notify system. The server will send you a
 message when any nickname in your watch list logs on or
 off. The watch list DOES NOT REMAIN BETWEEN SESSIONS -
 you (or your script or client) must add the nicknames
 to your watch list every time you connect to an IRC
 server.</pre>

*   <a name="HELPOP"></a>**HELPOP** 
    <pre> <em>Syntax:</em> /HELPOP ?<span style="text-decoration: underline;">topic</span> or !<span style="text-decoration: underline;">topic</span>

 HelpOp is a new system of getting IRC Server help. You
 type either /HELPOP ? &lt;help system topic&gt; or
 /HELPOP ! &lt;question&gt; The "?" in /HELPOP means
 query the help system and if you get no response you
 can choose '!' to send it to the Help Operators online.
 Using neither ? nor ! will mean the command will be
 first queried within the help system and if no match if
 found , it will be forwarded to the help operators</pre>

*   <a name="LIST"></a>**LIST** 
    <pre> <em>Syntax:</em> /LIST <span style="text-decoration: underline;">search string</span>

 If you don't include a search string, the default is to
 send you the entire unfiltered list of channels. Below
 are the options you can use, and what channels LIST
 will return when you use them.

 &gt;number - List channels with more than &lt;number&gt; people.
 &lt;number - List channels with less than &lt;number&gt; people.
 C&gt;number - List channels created between now and &lt;number&gt; minutes ago.
 C&lt;number - List channels created earlier than &lt;number&gt; minutes ago.
 T&gt;number - List channels whose topics are older than &lt;number&gt;
 T&lt;number - List channels whose topics are newer than &lt;number&gt; minutes.
 *mask* - List channels that match *mask*
 !*mask* - List channels that do not match *mask*</pre>

*   <a name="KNOCK"></a>**KNOCK** 
    <pre> <em>Syntax:</em> /KNOCK <span style="text-decoration: underline;">channel</span> <span style="text-decoration: underline;">message</span>

 Allows you to ‘knock’ on an invite only
 channel and ask for access. Will not work if channel
 has one of the following modes set: +K +V. Will also
 not work if you are banned</pre>

*   <a name="SETNAME"></a>**SETNAME** 
    <pre> <em>Syntax:</em> /SETNAME

 Allows users to change their ‘Real Name’
 without reconnecting</pre>

*   <a name="MODE"></a>**MODE** 
    <pre> <em>Syntax:</em> /MODE <span style="text-decoration: underline;">chan/nick</span> <span style="text-decoration: underline;">mode</span>

 Lets you set channel and user modes. See User &
 Channel Modes for a list.</pre>

*   <a name="CREDITS"></a>**CREDITS** 
    <pre> <em>Syntax:</em> /CREDITS

 Lists credits for everyone that has helped create
 UnrealIRCd</pre>

*   <a name="LICENSE"></a>**LICENSE** 
    <pre> <em>Syntax:</em> /LICENSE

 Displays the GNU License</pre>

*   <a name="TIME"></a>**TIME** 
    <pre> <em>Syntax:</em> /TIME <span style="text-decoration: underline;">server</span>

 Displays the servers date and time. Including a server
 name allows you to check other servers.</pre>

*   <a name="BOTMOTD"></a>**BOTMOTD** 
    <pre> <em>Syntax:</em> /BOTMOTD <span style="text-decoration: underline;">server</span>

 Displays the servers bot message of the day. Including
 a server name allows you to check other servers</pre>

*   <a name="IDENTIFY"></a>**IDENTIFY** 
    <pre> <em>Syntax:</em> /IDENTIFY <span style="text-decoration: underline;">password</span>

 Sends your password to the services system to identify
 to your nick.</pre>

*   <a name="IDENTIFYCHANNEL"></a>**IDENTIFY** 
    <pre> <em>Syntax:</em> /IDENTIFY <span style="text-decoration: underline;">channel</span> <span style="text-decoration: underline;">password</span>

 Sends your password to the services system to identify
 as the founder of a channel.</pre>

*   <a name="DNS"></a>**DNS** 
    <pre> <em>Syntax:</em> /DNS <span style="text-decoration: underline;">option</span>

 Returns information about the IRC server's DNS cache.
 Note, since most clients have a built-in DNS command,
 you will most likely need to use /raw DNS to use this.
 Opers may specify an l as the first parameter to the
 command  to receive a list of entries in the DNS cache.</pre>

*   <a name="USERIP"></a>**USERIP** 
    <pre> <em>Syntax:</em> /USERIP <span style="text-decoration: underline;">nick</span>

 Returns the IP address of the user in question. This will be
 shown encrypted.</pre>

*   <a name="STATS"></a>**STATS** 
    <pre> <em>Syntax:</em> /STATS <span style="text-decoration: underline;">option</span>

 <strong>Not all of the following STATS options are available to regular users</strong>

 B - banversion - Send the ban version list
 b - badword - Send the badwords list
 C - link - Send the link block list
 d - denylinkauto - Send the deny link (auto) block list
 D - denylinkall - Send the deny link (all) block list
 e - exceptthrottle - Send the except throttle block list
 E - exceptban - Send the except ban and except tkl block list
 f - spamfilter - Send the spamfilter list
 F - denydcc - Send the deny dcc block list
 G - gline - Send the gline and gzline list
   Extended flags: [+/-mrs] [mask] [reason] [setby]
     m Return glines matching/not matching the specified mask
     r Return glines matching/not matching the specified reason
     s Return glines set by/not set by clients matching the specified name
 I - allow - Send the allow block list
 j - officialchans - Send the offical channels list
 K - kline - Send the ban user/ban ip/except ban block list
 l - linkinfo - Send link information
 L - linkinfoall - Send all link information
 M - command - Send list of how many times each command was used
 n - banrealname - Send the ban realname block list
 O - oper - Send the oper block list
 P - port - Send information about ports
 q - sqline - Send the SQLINE list
 Q - bannick - Send the ban nick block list
 r - chanrestrict - Send the channel deny/allow block list
 R - usage - Send usage information
 S - set - Send the set block list
 s - shun - Send the shun list
   Extended flags: [+/-mrs] [mask] [reason] [setby]
     m Return shuns matching/not matching the specified mask
     r Return shuns matching/not matching the specified reason
     s Return shuns set by/not set by clients matching the specified name
 t - tld - Send the tld block list
 T - traffic - Send traffic information
 u - uptime - Send the server uptime and connection count
 U - uline - Send the ulines block list
 v - denyver - Send the deny version block list
 V - vhost - Send the vhost block list
 X - notlink - Send the list of servers that are not current linked
 Y - class - Send the class block list
 z - zip - Send compression information about ziplinked servers
 Z - mem - Send memory usage information</pre>

*   <a name="MODULE"></a>**MODULE** 
    <pre> <em>Syntax:</em> /MODULE

 Lists all loaded modules</pre>