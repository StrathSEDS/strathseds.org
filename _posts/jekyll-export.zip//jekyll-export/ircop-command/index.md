---
title: IRC Operator Commands
author: MrRandom
layout: page
---
*   **INVITE** 
    <pre> <em>Syntax:</em> /INVITE <span style="text-decoration: underline;">nick</span> <span style="text-decoration: underline;">channel</span>

 Invites the given user to the given channel. (Must be a
 channel Op)</pre>

*   <a name="KICK"></a>**KICK** 
    <pre> <em>Syntax:</em> /KICK <span style="text-decoration: underline;">channel, channel</span> <span style="text-decoration: underline;">user, user</span> <span style="text-decoration: underline;">reason</span>

 Kicks a user or users out of a channel, or channels. A
 reason may also be supplied.</pre>

*   <a name="OPER"></a>**OPER** 
    <pre> <em>Syntax:</em> /OPER <span style="text-decoration: underline;">userid</span> <span style="text-decoration: underline;">password</span>

 Command to give a user operator status if they match an
 Oper Block</pre>

*   <a name="WALLOPS"></a>**WALLOPS** 
    <pre> <em>Syntax:</em> /WALLOPS <span style="text-decoration: underline;">message</span>

 Sends a message to all users with umode +w</pre>

*   <a name="GLOBOPS"></a>**GLOBOPS** 
    <pre> <em>Syntax:</em> /GLOBOPS <span style="text-decoration: underline;">message</span>

 Sends a message to all global IRCops</pre>

*   <a name="CHATOPS"></a>**CHATOPS** 
    <pre> <em>Syntax:</em> /CHATOPS <span style="text-decoration: underline;">message</span>

 Sends a message to all IRCops (local and global)</pre>

*   <a name="LOCOPS"></a>**LOCOPS** 
    <pre> <em>Syntax:</em> /LOCOPS <span style="text-decoration: underline;">message</span>

 Sends a message to all local IRCops</pre>

*   <a name="ADCHAT"></a>**ADCHAT** 
    <pre> <em>Syntax:</em> /ADCHAT <span style="text-decoration: underline;">message</span>

 Sends a message to all Admins</pre>

*   <a name="NACHAT"></a>**NACHAT** 
    <pre> <em>Syntax:</em> /NACHAT <span style="text-decoration: underline;">message</span>

 Sends a message to all Net Admins</pre>

*   <a name="KILL"></a>**KILL** 
    <pre> <em>Syntax:</em> /KILL <span style="text-decoration: underline;">nick</span> <span style="text-decoration: underline;">reason</span>

 Kills a user from the network</pre>

*   <a name="KLINE"></a>**KLINE** 
    <pre> <em>Syntax:</em> /KLINE [+|-]<span style="text-decoration: underline;">user@host | nick</span> [<span style="text-decoration: underline;">time to ban</span> <span style="text-decoration: underline;">reason</span>]

 Bans the hostmask from the server it is issued on. A
 kline is not a global ban.   <strong>time to ban</strong> is
 either: a) a value in seconds, b) a time value, like
 '1d' is 1 day or c) '0' for permanent.  Time and reason
 are optional, if unspecified set::default-bantime
 (default: 0/permanent) and 'no reason' are used.  To
 remove a kline use /kline -user@host</pre>

*   <a name="ZLINE"></a>**ZLINE** 
    <pre> <em>Syntax:</em> /ZLINE [+|-]<span style="text-decoration: underline;">*@ip</span> [<span style="text-decoration: underline;">time to ban</span> <span style="text-decoration: underline;">reason</span>]

 Bans an IP Address from the local server it is issued
 on (not global). See kline for more syntax info.   Use
 /zline -*@ip to remove.</pre>

*   <a name="GLINE"></a>**GLINE** 
    <pre> <em>Syntax:</em> /GLINE [+|-]<span style="text-decoration: underline;">user@host | nick</span> [<span style="text-decoration: underline;">time to ban</span> <span style="text-decoration: underline;">reason</span>]

 Adds a global ban to anyone that matches. See kline for
 more syntax info.      Use /gline -user@host to remove.</pre>

*   <a name="SHUN"></a>**SHUN** 
    <pre> <em>Syntax:</em> /SHUN [+|-]<span style="text-decoration: underline;">user@host | nick</span> [<span style="text-decoration: underline;">time to shun</span> <span style="text-decoration: underline;">reason</span>]

 Prevents a user from executing ANY commands and
 prevents them from speaking. Shuns are global (like
 glines). See kline for more syntax info. Use /shun
 -user@host to remove a shun.</pre>

*   <a name="GZLINE"></a>**GZLINE** 
    <pre> <em>Syntax:</em> /GZLINE [+|-]<span style="text-decoration: underline;">ip</span> <span style="text-decoration: underline;">time to ban</span> :<span style="text-decoration: underline;">reason</span>

 Adds a global zline. See kline for more syntax info.
   Use /gzline -*@ip to remove a gzline.</pre>

*   <a name="REHASH"></a>**REHASH** 
    <pre> <em>Syntax:</em> /REHASH <span style="text-decoration: underline;">server</span> –<span style="text-decoration: underline;">flags</span>

 Rehashes the servers config file. Including a server
 name allows you to rehash a remote servers config file.
 Several flags are also available. They Include -motd -
 Only rehash all MOTD and RULES files (including tld {})
      -opermotd - Only rehash the OPERMOTD file
 -botmotd - Only rehash the BOTMOTD file      -garbage -
 Force garbage collection
IRCop</pre>

*   <a name="RESTART"></a>**RESTART** 
    <pre> <em>Syntax:</em> /RESTART <span style="text-decoration: underline;">password</span> <span style="text-decoration: underline;">reason</span>

 Restarts the IRCD Process. Password is required if
 drpass { } is present.   You may also include a reason.</pre>

*   <a name="DIE"></a>**DIE** 
    <pre> <em>Syntax:</em> /DIE <span style="text-decoration: underline;">password</span>

 Terminates the IRCD Process. Password is required if
 drpass { } is present.</pre>

*   <a name="LAG"></a>**LAG** 
    <pre> <em>Syntax:</em> /LAG <span style="text-decoration: underline;">server</span>

 This command is like a Sonar or Traceroute for IRC
 server. You type in /LAG irc.fyremoon.net and it will
 reply from every server it passes with time and so on.
 Useful for looking where lag is and optional TS
 future/past travels</pre>

*   <a name="SETHOST"></a>**SETHOST** 
    <pre> <em>Syntax:</em> /SETHOST <span style="text-decoration: underline;">newhost</span>

 Lets you change your vhost to what ever you want it to
 be.</pre>

*   <a name="SETIDENT"></a>**SETIDENT** 
    <pre> <em>Syntax:</em> /SETIDENT <span style="text-decoration: underline;">newident</span>

 Lets you set your ident to what ever you want it to be</pre>

*   <a name="CHGHOST"></a>**CHGHOST** 
    <pre> <em>Syntax:</em> /CHGHOST <span style="text-decoration: underline;">nick</span> <span style="text-decoration: underline;">newhost</span>

 Lets you change the host name of a user currently on
 the system</pre>

*   <a name="CHIDENT"></a>**CHGIDENT** 
    <pre> <em>Syntax:</em> /CHGIDENT <span style="text-decoration: underline;">nick</span> <span style="text-decoration: underline;">newident</span>

 Lets you change the ident of a user currently on the
 system</pre>

*   <a name="CHNAME"></a>**CHGNAME** 
    <pre> <em>Syntax:</em> /CHGNAME <span style="text-decoration: underline;">nick</span> <span style="text-decoration: underline;">newname</span>

 Lets you change the realname of a user currently on the
 system</pre>

*   <a name="SQUIT"></a>**SQUIT** 
    <pre> <em>Syntax:</em> /SQUIT <span style="text-decoration: underline;">server</span>

 Disconnects a server from the network</pre>

*   <a name="CONNECT"></a>**CONNECT** 
    <pre> <em>Syntax:</em> /CONNECT <span style="text-decoration: underline;">server</span> <span style="text-decoration: underline;">port</span> <span style="text-decoration: underline;">server</span>

 If only one server is given, it will attempt to connect
 the server you are ON to the given server. If 2 servers
 are given, it will attempt to connect the 2 servers
 together. Put the leaf server as the first, and the hub
 server as the second.</pre>

*   <a name="DCCENY"></a>**DCCDENY** 
    <pre> <em>Syntax:</em> /DCCDENY <span style="text-decoration: underline;">filemask</span> <span style="text-decoration: underline;">reason</span>

 Adds a DCCDENY for that filemask. Preventing that file
 from being sent.</pre>

*   <a name="UNDCCDENY"></a>**UNDCCDENY** 
    <pre> <em>Syntax:</em> /UNDCCDENY <span style="text-decoration: underline;">filemask</span>

 Removes a DCCDENY</pre>

*   <a name="SAJOIN"></a>**SAJOIN** 
    <pre> <em>Syntax:</em> /SAJOIN <span style="text-decoration: underline;">nick</span> <span style="text-decoration: underline;">channel</span>, <span style="text-decoration: underline;">channel</span>

 Forces a user to join a channel(s). Available to
 services & network admins only</pre>

*   <a name="SAPART"></a>**SAPART** 
    <pre> <em>Syntax:</em> /SAPART <span style="text-decoration: underline;">nick</span> <span style="text-decoration: underline;">channel</span>, <span style="text-decoration: underline;">channel</span>

 Forces a user to part a channel(s). Available to
 services & network admins only.</pre>

*   <a name="SAMODE"></a>**SAMODE** 
    <pre> <em>Syntax:</em> /SAMODE <span style="text-decoration: underline;">channel</span> <span style="text-decoration: underline;">mode</span>

 Allows Network & Services admins to change modes of a
 channel without having ChanOps.</pre>

*   <a name="RPING"></a>**RPING** 
    <pre> <em>Syntax:</em> /RPING <span style="text-decoration: underline;">servermask</span>

 Will calculate in milliseconds the lag between servers</pre>

*   <a name="TRACE"></a>**TRACE** 
    <pre> <em>Syntax:</em> /TRACE <span style="text-decoration: underline;">servermask|nickname</span>

 When used on a user it will give you class and lag
 info. If you use  it on a server it gives you
 class/version/link info.</pre>

*   <a name="OPERMOTD"></a>**OPERMOTD** 
    <pre> <em>Syntax:</em> /OPERMOTD

 Displays the servers OperMotd File</pre>

*   **ADDMOTD** 
    <pre> <em>Syntax:</em> /ADDMOTD :<span style="text-decoration: underline;">text</span>

 Will add the given text to the end of the Motd</pre>

*   <a name="ADDMOTD"></a>**ADDOMOTD** 
    <pre> <em>Syntax:</em> /ADDOMOTD :<span style="text-decoration: underline;">text</span>

 Will add the given text to the end of the OperMotd</pre>

*   <a name="SDESC"></a>**SDESC** 
    <pre> <em>Syntax:</em> /SDESC <span style="text-decoration: underline;">newdescription</span>

 Allows server admins to change the description line of
 their server without restarting.</pre>

*   <a name="ADDLINE"></a>**ADDLINE** 
    <pre> <em>Syntax:</em> /ADDLINE <span style="text-decoration: underline;">text</span>

 Allows you to add lines to the unrealircd.conf</pre>

*   <a name="MKPASSWD"></a>**MKPASSWD** 
    <pre> <em>Syntax:</em> /MKPASSWD <span style="text-decoration: underline;">password</span>

 Will encrypt a clear text password to add it to the
 unrealircd.conf</pre>

*   <a name="TSCTLOFFSET"></a>**TSCTL OFFSET** 
    <pre> <em>Syntax:</em> /TSCTL OFFSET +/- <span style="text-decoration: underline;">time</span>

 Adjust the IRCD’s Internal clock (Do NOT use if
 you do not understand EXACTLY what it does)</pre>

*   <a name="TSCTLTIME"></a>**TSCTL TIME** 
    <pre> <em>Syntax:</em> /TSCTL TIME

 Will give a TS Report</pre>

*   <a name="TSCTLALLTIME"></a>**TSCTL ALLTIME** 
    <pre> <em>Syntax:</em> /TSCTL ALLTIME

 Will give a TS Report of ALL servers</pre>

*   <a name="TSCTLSVSTIME"></a>**TSCTL SVSTIME** 
    <pre> <em>Syntax:</em> /TSCTL SVSTIME <span style="text-decoration: underline;">timestamp</span>

 Sets the TS time of all servers (Do NOT use if you do
 not understand EXACTLY what it does)</pre>

*   <a name="HTM"></a>**HTM** 
    <pre> <em>Syntax:</em> /HTM <span style="text-decoration: underline;">option</span>

 Controls settings related to high traffic mode. High
 Traffic Mode (HTM) basically disables certain user
 commands such as: list whois who etc in response to
 extremely high traffic on the server. Options include:
 -ON Forces server into HTM 
 -OFF Forces server out of HTM 
 -NOISY Sets the server to notify users/admins when
   in goes in and out of HTM      
 -QUIET Sets the server to NOT notify when going in 
   and out of HTM 
 -TO  &lt;value&gt; Tell HTM at what incoming rate to
 activate HTM</pre>

*   <a name="CLOSE"></a>**CLOSE** 
    <pre> <em>Syntax:</em> /CLOSE

 This command will disconnect all unknown connections
 from the IRC server.</pre>