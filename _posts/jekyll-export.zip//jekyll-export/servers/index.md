---
title: Servers
author: MrRandom
layout: page
---
This page shows all of our servers on the network. You often achieve the best connection by connecting to the server geographically closest to you. To do this, you can connect to servername.digitalirc.org – for example shire.digitalirc.org. If you would like to connect to a random server, you can connect to irc.digitalirc.org. You can also use one of our round robin pools to connect to a random server closest to your.  
  
<small>View <a href="https://maps.google.com/maps/ms?msa=0&msid=209799686244178199722.0004cb6424aa114855844&ie=UTF8&t=m&ll=46.316584,24.257813&spn=109.945326,225&z=2&source=embed" style="color:#0000FF;text-align:left">Digital IRC</a> in a larger map</small>

<h1 style="text-align: center;">
  IRC Servers
</h1>

&nbsp;

<table width="100%" align="center">
  <tr class="row-1 odd">
    <th class="column-1" width="25%">
      Server Name
    </th>
    
    <th class="column-2" width="25%">
      Location
    </th>
    
    <th class="column-3" width="25%">
      Admin
    </th>
    
    <th class="column-4" width="25%">
      IPv6 Enabled
    </th>
  </tr>
  
  <tr class="row-2 even">
    <td class="column-1">
      <a href="http://www.digitalirc.org/stats/?m=n&p=srvdetails&srv=irc.digitalirc.org" target="_blank">irc.digitalirc.org</a>
    </td>
    
    <td class="column-2">
      Virginia, USA
    </td>
    
    <td class="column-3">
      DippingSauce
    </td>
    
    <td class="column-4">
    </td>
  </tr>
  
  <tr class="row-3 odd">
    <td class="column-1">
      <a href="http://www.digitalirc.org/stats/?m=n&p=srvdetails&srv=mooo.digitalirc.org" target="_blank">mooo.digitalirc.org</a>
    </td>
    
    <td class="column-2">
      Aubusson, FR
    </td>
    
    <td class="column-3">
      Barumba
    </td>
    
    <td class="column-4" align="center">
      <a href="http://i1.wp.com/www.digitalirc.org/wp-content/uploads/2012/09/rsz_nab-tick-hi.png"><img class="alignnone size-full wp-image-77" title="tick-hi" src="http://i1.wp.com/www.digitalirc.org/wp-content/uploads/2012/09/rsz_nab-tick-hi.png?fit=30%2C30" alt="Yes" data-recalc-dims="1" /></a>
    </td>
  </tr>
  
  <tr class="row-4 even">
    <td class="column-1">
      <a href="http://www.digitalirc.org/stats/?m=n&p=srvdetails&srv=exodus.digitalirc.org" target="_blank">exodus.digitalirc.org</a>
    </td>
    
    <td class="column-2">
      Paris. FR
    </td>
    
    <td class="column-3">
      Clownius
    </td>
    
    <td class="column-4">
    </td>
  </tr>
  
  <tr class="row-5 odd">
    <td class="column-1">
      <a href="http://www.digitalirc.org/stats/?m=n&p=srvdetails&srv=shire.digitalirc.org" target="_blank">shire.digitalirc.org</a>
    </td>
    
    <td class="column-2">
      Sheffield, UK
    </td>
    
    <td class="column-3">
      MrRandom
    </td>
    
    <td class="column-4" align="center">
      <a href="http://i1.wp.com/www.digitalirc.org/wp-content/uploads/2012/09/rsz_nab-tick-hi.png"><img class="alignnone size-full wp-image-77" title="tick-hi" src="http://i1.wp.com/www.digitalirc.org/wp-content/uploads/2012/09/rsz_nab-tick-hi.png?fit=30%2C30" alt="Yes" data-recalc-dims="1" /></a>
    </td>
  </tr>
</table>

&nbsp;

&nbsp;

<h1 style="text-align: center;">
  Other Servers
</h1>

<table width="100%" align="center">
  <tr class="row-1 odd">
    <th class="column-1" width="33%">
      Server Name
    </th>
    
    <th class="column-2" width="33%">
      Admin
    </th>
    
    <th class="column-3" width="34%">
      Purpose
    </th>
  </tr>
  
  <tr class="row-2 even">
    <td class="column-1">
      <a title="IRC Commands" href="http://www.digitalirc.org/commands/" target="_blank">Services.int</a>
    </td>
    
    <td class="column-2">
      MrRandom & Barumba
    </td>
    
    <td class="column-3">
      Anope Services Server
    </td>
  </tr>
  
  <tr class="row-3 odd">
    <td class="column-1">
      <a href="http://www.digitalirc.org/stats/" target="_blank">Stats.int</a>
    </td>
    
    <td class="column-2">
      DigitalIRC admins
    </td>
    
    <td class="column-3">
      Denora Stats Server
    </td>
  </tr>
  
  <tr class="row-4 even">
    <td class="column-1">
      lucifer.services.int
    </td>
    
    <td class="column-2">
      The Devil
    </td>
    
    <td class="column-3">
      IRC 2 MySQL gateway
    </td>
  </tr>
  
  <tr class="row-5 odd">
    <td class="column-1">
      test.server
    </td>
    
    <td class="column-2">
      DigitalIRC Admins
    </td>
    
    <td class="column-3">
      Server used to test ideas before live testing on the production servers
    </td>
  </tr>
  
  <tr class="row-6 even">
    <td class="column-1">
      <a title="DigitalIRC" href="http://www.digitalirc.org/" target="_blank">www.digitalirc.org</a>
    </td>
    
    <td class="column-2">
      DigitalIRC Admins
    </td>
    
    <td class="column-3">
      Primary webserver
    </td>
  </tr>
</table>