---
title: BotServ
author: MrRandom
layout: page
---
<a name="ACT"><br /> <h2>
  ACT
</h2>

<p>
  </a>
</p>

<p>
  Makes the bot do the equivalent of a &#8220;/me&#8221; command<br /> on the given channel using the given text.
</p>

<p>
  <strong>Syntax:</strong> <tt>ACT <chan> <text></tt>
</p>

<p>
  <strong>Examples:</strong><br /> <br /><tt>/msg BotServ ACT #help yawns!</tt><br /> <a name="ASSIGN"><br /> <h2>
    ASSIGN
  </h2>
  
  <p>
    </a>
  </p>
  
  <p>
    Assigns a bot pointed out by nick to the channel chan. You<br /> can then configure the bot for the channel so it fits<br /> your needs.
  </p>
  
  <p>
    <strong>Syntax:</strong> <tt>ASSIGN <chan> <nick></tt>
  </p>
  
  <p>
    <strong>Examples:</strong><br /> <br /><tt>/msg BotServ ASSIGN #help Security</tt><br /> <a name="BOT"><br /> <h2>
      BOT
    </h2>
    
    <p>
      </a>
    </p>
    
    <p>
      Allows opers to create, modify, and delete bots<br /> that users will be able to use on their own channels.
    </p>
    
    <p>
      BOT ADD adds a bot with the given nickname, username,<br /> hostname and realname. Since no integrity checks are done<br /> for these settings, be careful.
    </p>
    
    <p>
      BOT CHANGE allows you to change nickname, username, hostname<br /> or realname of a bot without actually deleting it (and all<br /> the data associated with it).
    </p>
    
    <p>
      BOT DEL removes the given bot from the bot list.
    </p>
    
    <p>
      Note: you cannot create a bot that has a nick that is<br /> currently registered. If an unregistered user is currently<br /> using the nick, they will be killed.
    </p>
    
    <p>
      <strong>Syntax:</strong> <tt>BOT ADD <nick> <user> <host> <real></tt><br /> <strong>Syntax:</strong> <tt>BOT CHANGE <oldnick> <newnick> [<user> [<host> [<real>]]]</tt><br /> <strong>Syntax:</strong> <tt>BOT DEL <nick></tt>
    </p>
    
    <p>
      <strong>Examples:</strong><br /> <br /><tt>/msg BotServ BOT ADD Security Security security.example.net Security</tt><br /> <br /><tt>/msg BotServ BOT CHANGE Security NetBot NetBot Services.Example.Net MyNet</tt><br /> <br /><tt>/msg BotServ BOT DEL Security</tt><br /> <a name="BOTLIST"><br /> <h2>
        BOTLIST
      </h2>
      
      <p>
        </a>
      </p>
      
      <p>
        Lists all available bots on this network.
      </p>
      
      <p>
        <strong>Syntax:</strong> <tt>BOTLIST</tt>
      </p>
      
      <p>
        <strong>Examples:</strong><br /> <br /><tt>/msg BotServ BOTLIST</tt><br /> <a name="INFO"><br /> <h2>
          INFO
        </h2>
        
        <p>
          </a>
        </p>
        
        <p>
          INFO allows you to see BotServ information about a channel or a bot.
        </p>
        
        <p>
          <strong>Syntax:</strong> <tt>INFO <#channel|botnick></tt><br /> <a name="SAY"><br /> <h2>
            SAY
          </h2>
          
          <p>
            </a>
          </p>
          
          <p>
            Makes the bot say the given text on the given channel.
          </p>
          
          <p>
            <strong>Syntax:</strong> <tt>SAY <chan> <text></tt>
          </p>
          
          <p>
            <strong>Examples:</strong><br /> <br /><tt>/msg BotServ SAY #help Welcome to #help!</tt><br /> <a name="SET FANTASY"><br /> <h2>
              SET FANTASY
            </h2>
            
            <p>
              </a>
            </p>
            
            <p>
              Enables or disables fantasy mode on a channel.<br /> When it is enabled, users will be able to use all<br /> chanserv commands like !op, !deop, !voice, !devoice,<br /> !kick, !kb, !unban, !akick, !info on a channel.
            </p>
            
            <p>
              <strong>Syntax:</strong> <tt>SET <#channel> FANTASY {ON|OFF}</tt>
            </p>
            
            <p>
              <strong>Examples:</strong><br /> <br /><tt>/msg BotServ SET #help FANTASY ON</tt><br /> <a name="SET NOBOT"><br /> <h2>
                SET NOBOT
              </h2>
              
              <p>
                </a>
              </p>
              
              <p>
                This option makes a channel be unassignable. If a bot<br /> is already assigned to the channel, it is unassigned<br /> automatically when you enable the option.
              </p>
              
              <p>
                <strong>Syntax:</strong> <tt>SET <#channel> NOBOT {ON|OFF}</tt>
              </p>
              
              <p>
                <strong>Examples:</strong><br /> <br /><tt>/msg BotServ SET #help NOBOT ON</tt><br /> <a name="SET PRIVATE"><br /> <h2>
                  SET PRIVATE
                </h2>
                
                <p>
                  </a>
                </p>
                
                <p>
                  This option prevents a bot from being assigned to a<br /> channel by users that do not have chan:admin privilege.
                </p>
                
                <p>
                  <strong>Syntax:</strong> <tt>SET <botnick> PRIVATE {ON|OFF}</tt>
                </p>
                
                <p>
                  <strong>Examples:</strong><br /> <br /><tt>/msg BotServ SET Security PRIVATE ON</tt><br /> <a name="UNASSIGN"><br /> <h2>
                    UNASSIGN
                  </h2>
                  
                  <p>
                    </a>
                  </p>
                  
                  <p>
                    Unassigns a bot from a channel. When you use this command,<br /> the bot won&#8217;t join the channel anymore. However, bot<br /> configuration for the channel is kept, so you will always<br /> be able to reassign a bot later without having to reconfigure<br /> it entirely.
                  </p>
                  
                  <p>
                    <strong>Syntax:</strong> <tt>UNASSIGN <chan></tt>
                  </p>
                  
                  <p>
                    <strong>Examples:</strong><br /> <br /><tt>/msg BotServ UNASSIGN #help</tt>
                  </p>