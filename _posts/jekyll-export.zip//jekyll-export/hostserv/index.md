---
title: HostServ
author: MrRandom
layout: page
---
<a name="ACTIVATE"><br /> <h2>
  ACTIVATE
</h2>

<p>
  </a>
</p>

<p>
  Activate the requested vHost for the given nick.<br /> A memo informing the user will also be sent.<br /> If an asterisk (&#8220;*&#8221;) is used in place of a nick,<br /> all waiting vHosts will be activated.
</p>

<p>
  <strong>Syntax:</strong> <tt>ACTIVATE <nick></tt>
</p>

<p>
  <strong>Examples:</strong><br /> <br /><tt>/msg HostServ ACTIVATE nenolod</tt><br /> <br /><tt>/msg HostServ ACTIVATE *</tt><br /> <a name="GROUP"><br /> <h2>
    GROUP
  </h2>
  
  <p>
    </a>
  </p>
  
  <p>
    This command will set the current nick&#8217;s vhost as the<br /> vhost for all the nicks in the group, including nicks<br /> that will be added in the future.
  </p>
  
  <p>
    <strong>Syntax:</strong> <tt>GROUP</tt>
  </p>
  
  <p>
    <strong>Examples:</strong><br /> <br /><tt>/msg HostServ GROUP</tt><br /> <a name="LISTVHOST"><br /> <h2>
      LISTVHOST
    </h2>
    
    <p>
      </a>
    </p>
    
    <p>
      LISTVHOST allows operators to see virtual hosts (also<br /> known as spoofs or cloaks) matching a given pattern.<br /> If no pattern is specified, it lists all existing vhosts.
    </p>
    
    <p>
      <strong>Syntax:</strong> <tt>LISTVHOST [<pattern>]</tt>
    </p>
    
    <p>
      <strong>Examples:</strong><br /> <br /><tt>/msg HostServ LISTVHOST *lulz.com*</tt><br /> <br /><tt>/msg HostServ LISTVHOST</tt><br /> <a name="OFF"><br /> <h2>
        OFF
      </h2>
      
      <p>
        </a>
      </p>
      
      <p>
        Deactivates the vhost currently assigned to the nick in use.<br /> When you use this command, any user who performs a /whois<br /> on your nick will see your real IP address.
      </p>
      
      <p>
        For permanent removal of your vhost, please see network staff.
      </p>
      
      <p>
        <strong>Syntax:</strong> <tt>OFF</tt>
      </p>
      
      <p>
        <strong>Examples:</strong><br /> <br /><tt>/msg HostServ OFF</tt><br /> <a name="OFFER"><br /> <h2>
          OFFER
        </h2>
        
        <p>
          </a>
        </p>
        
        <p>
          OFFER allows you to offer a list of vhosts to the users<br /> of your network that they can accept at will without needing<br /> an oper to set the vhost. The string $account in the offered<br /> vhost will be replaced by a users&#8217; account name when they TAKE it.
        </p>
        
        <p>
          If the !group parameter is provided, only users with the +v flag<br /> in that group will be able to see it in OFFERLIST and TAKE it.
        </p>
        
        <p>
          <strong>Syntax:</strong> <tt>OFFER [!group] <vhost></tt>
        </p>
        
        <p>
          <strong>Examples:</strong><br /> <br /><tt>/msg HostServ OFFER may.explode.on.impact</tt><br /> <br /><tt>/msg HostServ OFFER mynetwork.users.$account</tt><br /> <br /><tt>/msg HostServ OFFER !atheme-users $account.users.atheme.net</tt><br /> <a name="OFFERLIST"><br /> <h2>
            OFFERLIST
          </h2>
          
          <p>
            </a>
          </p>
          
          <p>
            OFFERLIST lists all vhosts currently available from<br /> the network staff.
          </p>
          
          <p>
            <strong>Syntax:</strong> <tt>OFFERLIST</tt>
          </p>
          
          <p>
            <strong>Examples:</strong><br /> <br /><tt>/msg HostServ OFFERLIST</tt><br /> <a name="ON"><br /> <h2>
              ON
            </h2>
            
            <p>
              </a>
            </p>
            
            <p>
              Activates the vhost currently assigned to the nick in use.<br /> When you use this command any user who performs a /whois<br /> on you will see the vhost instead of your real IP address.
            </p>
            
            <p>
              <strong>Syntax:</strong> <tt>ON</tt>
            </p>
            
            <p>
              <strong>Examples:</strong><br /> <br /><tt>/msg HostServ ON</tt><br /> <a name="REJECT"><br /> <h2>
                REJECT
              </h2>
              
              <p>
                </a>
              </p>
              
              <p>
                Reject the requested vHost for the given nick.<br /> A memo informing the user will also be sent.<br /> If an asterisk (&#8220;*&#8221;) is used in place of a nick,<br /> all waiting vHosts will be rejected.
              </p>
              
              <p>
                <strong>Syntax:</strong> <tt>REJECT <nick></tt>
              </p>
              
              <p>
                <strong>Examples:</strong><br /> <br /><tt>/msg HostServ REJECT nenolod</tt><br /> <br /><tt>/msg HostServ REJECT *</tt><br /> <a name="REQUEST"><br /> <h2>
                  REQUEST
                </h2>
                
                <p>
                  </a>
                </p>
                
                <p>
                  REQUEST activation of the vhost. You must be <b>identified</b><br /> to a registered nick to issue this command. Please be<br /> patient while your request is considered by network staff.
                </p>
                
                <p>
                  <strong>Syntax:</strong> <tt>REQUEST <vhost></tt>
                </p>
                
                <p>
                  <strong>Examples:</strong><br /> <br /><tt>/msg HostServ REQUEST may.explode.on.impact</tt><br /> <a name="TAKE"><br /> <h2>
                    TAKE
                  </h2>
                  
                  <p>
                    </a>
                  </p>
                  
                  <p>
                    TAKE allows you to set a vhost that the network staff<br /> has offered and use it on your account. If the string<br /> $account is in the vhost, it will be replaced with your<br /> account name.
                  </p>
                  
                  <p>
                    <strong>Syntax:</strong> <tt>TAKE <vhost></tt>
                  </p>
                  
                  <p>
                    <strong>Examples:</strong><br /> /msg HostServ TAKE $account.users.example.net<br /> /msg HostServ TAKE example.net<br /> <a name="UNOFFER"><br /> <h2>
                      UNOFFER
                    </h2>
                    
                    <p>
                      </a>
                    </p>
                    
                    <p>
                      Remove a offered vhost from the OFFER list.
                    </p>
                    
                    <p>
                      <strong>Syntax:</strong> <tt>UNOFFER <vhost></tt>
                    </p>
                    
                    <p>
                      <strong>Examples:</strong><br /> <br /><tt>/msg HostServ UNOFFER users.example.net</tt><br /> <a name="VHOST"><br /> <h2>
                        VHOST
                      </h2>
                      
                      <p>
                        </a>
                      </p>
                      
                      <p>
                        VHOST allows operators to set a virtual host (also<br /> known as a spoof or cloak) on an account. This vhost<br /> will be set on the user immediately and each time<br /> they identify to their account. If no vhost is<br /> specified, it will clear all existing vhosts on the account.
                      </p>
                      
                      <p>
                        <strong>Syntax:</strong> <tt>VHOST <nickname> [<vhost>]</tt>
                      </p>
                      
                      <p>
                        <strong>Examples:</strong><br /> <br /><tt>/msg HostServ VHOST spb may.explode.on.impact</tt><br /> <br /><tt>/msg HostServ VHOST nenolod</tt><br /> <a name="VHOSTNICK"><br /> <h2>
                          VHOSTNICK
                        </h2>
                        
                        <p>
                          </a>
                        </p>
                        
                        <p>
                          VHOSTNICK allows operators to set a virtual host (also<br /> known as a spoof or cloak) on a nick. This vhost<br /> will be set on the user immediately and each time<br /> they identify when using said nick. If no vhost is<br /> specified, revert to the account&#8217;s vhost.
                        </p>
                        
                        <p>
                          <strong>Syntax:</strong> <tt>VHOSTNICK <nickname> [<vhost>]</tt>
                        </p>
                        
                        <p>
                          <strong>Examples:</strong><br /> <br /><tt>/msg HostServ VHOSTNICK spb may.explode.on.impact</tt><br /> <br /><tt>/msg HostServ VHOSTNICK nenolod</tt><br /> <a name="WAITING"><br /> <h2>
                            WAITING
                          </h2>
                          
                          <p>
                            </a>
                          </p>
                          
                          <p>
                            WAITING lists all vhosts currently waiting for activation.
                          </p>
                          
                          <p>
                            <strong>Syntax:</strong> <tt>WAITING</tt>
                          </p>
                          
                          <p>
                            <strong>Examples:</strong><br /> <br /><tt>/msg HostServ WAITING</tt>
                          </p>