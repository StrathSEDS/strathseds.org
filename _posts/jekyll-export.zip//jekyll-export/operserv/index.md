---
title: OperServ
author: MrRandom
layout: page
---
<a name="AKILL"><br /> <h2>
  AKILL
</h2>

<p>
  </a>
</p>

<p>
  AKILL allows you to maintain network-wide bans a la DALnet AKILL.<br /> Services will keep your AKILLs stored and allow for easy management.
</p>

<p>
  <strong>Syntax:</strong> <tt>AKILL ADD <nick|hostmask> [!P|!T <minutes>] <reason></tt>
</p>

<p>
  If the !P token is specified the AKILL will never expire (permanent).<br /> If the !T token is specified expire time must follow, in minutes,<br /> hours (&#8220;h&#8221;), days (&#8220;d&#8221;) or weeks (&#8220;w&#8221;).
</p>

<p>
  <strong>Examples:</strong><br /> <br /><tt>/msg OperServ AKILL ADD foo !T 5 bar reason</tt><br /> <br /><tt>/msg OperServ AKILL ADD foo !T 3d bar reason</tt><br /> <br /><tt>/msg OperServ AKILL ADD foo@bar.com !P foo reason</tt><br /> <br /><tt>/msg OperServ AKILL ADD foo@bar.com foo reason</tt>
</p>

<p>
  The first example looks for the user with a nickname of &#8220;foo&#8221; and adds<br /> a 5 minute AKILL for &#8220;bar reason.&#8221;
</p>

<p>
  The second example is similar but adds the AKILL for 3 days instead of<br /> 5 minutes.
</p>

<p>
  The third example adds a permanent AKILL on foo@bar.com for &#8220;foo reason.&#8221;
</p>

<p>
  The fourth example adds a AKILL on foo@bar.com for the duration specified<br /> in the configuration file for &#8220;foo reason.&#8221;
</p>

<p>
  <strong>Syntax:</strong> <tt>AKILL DEL <hostmask|number></tt>
</p>

<p>
  If number is specified it correlates with the number on AKILL LIST.<br /> You may specify multiple numbers by separating with commas.<br /> You may specify a range by using a colon.
</p>

<p>
  <strong>Examples:</strong><br /> <br /><tt>/msg OperServ AKILL DEL foo@bar.com</tt><br /> <br /><tt>/msg OperServ AKILL DEL 5</tt><br /> <br /><tt>/msg OperServ AKILL DEL 1,2,5,10</tt><br /> <br /><tt>/msg OperServ AKILL DEL 1:5,7,9:11</tt>
</p>

<p>
  <strong>Syntax:</strong> <tt>AKILL LIST [FULL]</tt>
</p>

<p>
  If FULL is specified the AKILL reasons will be shown.
</p>

<p>
  <strong>Examples:</strong><br /> <br /><tt>/msg OperServ AKILL LIST</tt><br /> <br /><tt>/msg OperServ AKILL LIST FULL</tt>
</p>

<p>
  <strong>Syntax:</strong> <tt>AKILL LIST <hostmask></tt>
</p>

<p>
  Shows any AKILLs matching the given hostmask, with reasons.<br /> This command will not perform DNS lookups on a host,<br /> for best results repeat it with host and IP address.
</p>

<p>
  <strong>Examples:</strong><br /> <br /><tt>/msg OperServ AKILL LIST test@192.168.1.1</tt>
</p>

<p>
  <strong>Syntax:</strong> <tt>AKILL LIST <number></tt>
</p>

<p>
  Shows the given AKILL, with reason.
</p>

<p>
  <strong>Syntax:</strong> <tt>AKILL SYNC</tt>
</p>

<p>
  Sends all akills to all servers. This can be useful in case<br /> services will be down or do not see a user as matching a<br /> certain akill.<br /> <a name="CLEARCHAN"><br /> <h2>
    CLEARCHAN
  </h2>
  
  <p>
    </a>
  </p>
  
  <p>
    CLEARCHAN allows operators to clear<br /> a channel in one of three ways: KICK,<br /> which kicks all users from the channel, KILL,<br /> which kills all users in the channel off the<br /> network, or AKILL, which sets a one week<br /> network ban against the hosts of all users in<br /> the channel.
  </p>
  
  <p>
    This command should not be used lightly.
  </p>
  
  <p>
    <strong>Syntax:</strong> <tt>CLEARCHAN KICK|KILL|AKILL <#channel> <reason></tt>
  </p>
  
  <p>
    <strong>Example:</strong><br /> <br /><tt>/msg OperServ CLEARCHAN KICK #warez warez is bad, mk?</tt><br /> <br /><tt>/msg OperServ CLEARCHAN AKILL #warez you were warned!</tt><br /> <a name="CLONES"><br /> <h2>
      CLONES
    </h2>
    
    <p>
      </a>
    </p>
    
    <p>
      CLONES keeps track of the number of clients<br /> per IP address. Warnings are displayed in<br /> the snoop channel about IP addresses with<br /> multiple clients.
    </p>
    
    <p>
      CLONES only works on clients whose IP address<br /> Atheme knows. If the ircd does not support<br /> propagating IP addresses at all, CLONES is<br /> not useful; if IP addresses are not sent for<br /> spoofed clients, those clients are exempt from<br /> CLONES checking.
    </p>
    
    <p>
      <strong>Syntax:</strong> <tt>CLONES KLINE ON|OFF</tt>
    </p>
    
    <p>
      Enables/disables banning IP addresses with more<br /> than the allowed number clients from the network<br /> for one hour (these bans are not added to the<br /> AKILL list). This setting is saved in etc/services.db<br /> and defaults to off.
    </p>
    
    <p>
      <strong>Syntax:</strong> <tt>CLONES LIST</tt>
    </p>
    
    <p>
      Shows all IP addresses with more than 3 clients<br /> with the number of clients and whether the IP<br /> address is exempt.
    </p>
    
    <p>
      <strong>Syntax:</strong> <tt>CLONES ADDEXEMPT <ip> <clones> [!P|!T <minutes>] <reason></tt>
    </p>
    
    <p>
      Adds an IP address to the clone exemption list.<br /> The IP address must match exactly with the form<br /> used by the ircd (mind &#8216;::&#8217; shortening with IPv6).<br /> The IP address can also be a CIDR mask, for example<br /> 192.168.1.0/24. Single IPs take priority above CIDR.<br /> <clones> is the number of clones allowed; it must be<br /> at least 4. Warnings are sent if this number is<br /> met, and a network ban may be set if the number<br /> is exceeded.<br /> The reason is shown in LISTEXEMPT.<br /> The clone exemption list is stored in etc/services.db.
    </p>
    
    <p>
      <strong>Syntax:</strong> <tt>CLONES DELEXEMPT <ip></tt>
    </p>
    
    <p>
      Removes an IP address from the clone exemption list.
    </p>
    
    <p>
      <strong>Syntax:</strong> <tt>CLONES SETEXEMPT [DEFAULT | <ip>] <ALLOWED | WARN | KILL> <limit></tt>
    </p>
    
    <p>
      Sets either the default or a given exemption&#8217;s ALLOWED,<br /> WARN, or KILL limit to the specified number of clones.<br /> WARN or KILL can be 0, disabling any warning messages or kills.
    </p>
    
    <p>
      <strong>Syntax:</strong> <tt>CLONES SETEXEMPT <ip> <REASON | DURATION> <value></tt>
    </p>
    
    <p>
      Sets the reason or duration of a given exemption to the<br /> specified value. The DURATION value can be 0, making the<br /> exemption permanent.
    </p>
    
    <p>
      <strong>Syntax:</strong> <tt>CLONES LISTEXEMPT</tt>
    </p>
    
    <p>
      Shows the clone exemption list with reasons.
    </p>
    
    <p>
      <strong>Example:</strong><br /> <br /><tt>/msg OperServ CLONES ADDEXEMPT 127.0.0.1 100 local</tt><br /> <br /><tt>/msg OperServ CLONES DELEXEMPT 192.168.1.2</tt>
    </p>
    
    <p>
      <strong>Syntax:</strong> <tt>CLONES DURATION</tt>
    </p>
    
    <p>
      Allows modifying the duration that hosts who clone<br /> are banned for. Defaults to one hour. Is saved between<br /> restarts.
    </p>
    
    <p>
      <strong>Example:</strong><br /> <br /><tt>/msg OperServ CLONES DURATION 30m</tt>
    </p>
    
    <p>
      <a name="COMPARE"><br /> <h2>
        COMPARE
      </h2>
      
      <p>
        </a>
      </p>
      
      <p>
        COMPARE allows operators with chan:auspex<br /> privilege to view matching information<br /> on two users, or two channels.
      </p>
      
      <p>
        It is useful in clone detection,<br /> amongst other situations.
      </p>
      
      <p>
        <strong>Syntax:</strong> <tt>COMPARE <#channel|user> <#channel|user></tt>
      </p>
      
      <p>
        <strong>Example:</strong><br /> <br /><tt>/msg OperServ COMPARE #warez #dcc</tt><br /> <br /><tt>/msg OperServ COMPARE w00t Brik</tt><br /> <a name="GREPLOG"><br /> <h2>
          GREPLOG
        </h2>
        
        <p>
          </a>
        </p>
        
        <p>
          GREPLOG searches through services logs and<br /> displays matching lines.
        </p>
        
        <p>
          The first parameter is either a service name<br /> (to search all commands given to that service)<br /> or an asterisk (to search all changes to services<br /> data).
        </p>
        
        <p>
          The second parameter is the pattern to search for.<br /> It may contain * and ? wildcards and should usually<br /> start and end in *.
        </p>
        
        <p>
          The optional third parameter is the number of<br /> previous days to search in addition to today.
        </p>
        
        <p>
          Note that this command will only work if sufficient<br /> information is written to log files.
        </p>
        
        <p>
          <strong>Syntax:</strong> <tt>GREPLOG <service> <pattern> [days]</tt><br /> <strong>Syntax:</strong> <tt>GREPLOG * <pattern> [days]</tt>
        </p>
        
        <p>
          <strong>Examples:</strong><br /> <br /><tt>/msg OperServ GREPLOG ChanServ *#somechan* 7</tt><br /> <br /><tt>/msg OperServ GREPLOG * *#somechan* 60</tt><br /> <a name="IGNORE"><br /> <h2>
            IGNORE
          </h2>
          
          <p>
            </a>
          </p>
          
          <p>
            Services has an ignore list which functions similarly to<br /> the way a user can ignore another user. If a user matches<br /> a mask in the ignore list and attempts to use services,<br /> they will not get a reply.
          </p>
          
          <p>
            <br /><tt>ADD - Add a mask to the ignore list.</tt><br /> <br /><tt>DEL - Delete a mask from the ignore list.</tt><br /> <br /><tt>LIST - List all the entries in the ignore list.</tt><br /> <br /><tt>CLEAR - Clear all the entries in the ignore list.</tt>
          </p>
          
          <p>
            <strong>Examples:</strong><br /> <br /><tt>/msg OperServ IGNORE ADD pfish!*@* flooding services</tt><br /> <br /><tt>/msg OperServ IGNORE DEL pfish!*@*</tt><br /> <br /><tt>/msg OperServ IGNORE LIST</tt><br /> <br /><tt>/msg OperServ IGNORE CLEAR</tt><br /> <a name="INFO"><br /> <h2>
              INFO
            </h2>
            
            <p>
              </a>
            </p>
            
            <p>
              INFO shows some services configuration information<br /> that is not available to see elsewhere.
            </p>
            
            <p>
              <strong>Syntax:</strong> <tt>INFO</tt><br /> <a name="JUPE"><br /> <h2>
                JUPE
              </h2>
              
              <p>
                </a>
              </p>
              
              <p>
                JUPE introduces a fake server with the given name, so<br /> that the real server cannot connect. Jupes only last<br /> as long as services is connected to the uplink and<br /> can also (on most ircds) be removed with a simple<br /> /squit command.
              </p>
              
              <p>
                <strong>Syntax:</strong> <tt>JUPE <server> <reason></tt>
              </p>
              
              <p>
                <strong>Example:</strong><br /> <br /><tt>/msg OperServ JUPE irc.blah.net very unstable server</tt><br /> <a name="MODE"><br /> <h2>
                  MODE
                </h2>
                
                <p>
                  </a>
                </p>
                
                <p>
                  MODE allows for the editing of modes on a channel. Some networks<br /> will most likely find this command to be unethical.
                </p>
                
                <p>
                  <strong>Syntax:</strong> <tt>MODE <#channel> <mode> [parameters]</tt>
                </p>
                
                <p>
                  <strong>Examples:</strong><br /> <br /><tt>/msg OperServ MODE #heh -m</tt><br /> <br /><tt>/msg OperServ MODE #heh +o foo</tt><br /> <a name="MODINSPECT"><br /> <h2>
                    MODINSPECT
                  </h2>
                  
                  <p>
                    </a>
                  </p>
                  
                  <p>
                    MODINSPECT displays detailed information about a module.
                  </p>
                  
                  <p>
                    The names can be gathered from the MODLIST command. They<br /> are not necessarily equal to the pathnames to load them<br /> with MODLOAD.
                  </p>
                  
                  <p>
                    <strong>Syntax:</strong> <tt>MODINSPECT <name></tt>
                  </p>
                  
                  <p>
                    <strong>Example:</strong><br /> <br /><tt>/msg OperServ MODINSPECT protocol/charybdis</tt><br /> <a name="MODLIST"><br /> <h2>
                      MODLIST
                    </h2>
                    
                    <p>
                      </a>
                    </p>
                    
                    <p>
                      MODLIST displays a listing of all loaded<br /> modules and their addresses.
                    </p>
                    
                    <p>
                      <strong>Syntax:</strong> <tt>MODLIST</tt><br /> <a name="MODLOAD"><br /> <h2>
                        MODLOAD
                      </h2>
                      
                      <p>
                        </a>
                      </p>
                      
                      <p>
                        MODLOAD loads one or more modules.
                      </p>
                      
                      <p>
                        If the path does not start with a slash, it is taken<br /> relative to PREFIX/modules or PREFIX/lib/atheme/modules<br /> (depending on how Atheme was compiled). Specifying a<br /> suffix like .so is optional.
                      </p>
                      
                      <p>
                        If any of the modules need a rehash after being<br /> loaded, this is done automatically.
                      </p>
                      
                      <p>
                        <strong>Syntax:</strong> <tt>MODLOAD <path...></tt>
                      </p>
                      
                      <p>
                        <strong>Example:</strong><br /> <br /><tt>/msg OperServ MODLOAD ../contrib/fc_dice</tt><br /> Help for ^BMODRELOAD^B:
                      </p>
                      
                      <p>
                        MODRELOAD reloads a currently loaded module. If the command fails,<br /> the module in question will be unloaded until errors are corrected.
                      </p>
                      
                      <p>
                        <strong>Syntax:</strong> <tt>MODRELOAD <name...></tt>
                      </p>
                      
                      <p>
                        <strong>Example:</strong><br /> <br /><tt>/msg OperServ MODRELOAD chanserv/register</tt><br /> <a name="MODUNLOAD"><br /> <h2>
                          MODUNLOAD
                        </h2>
                        
                        <p>
                          </a>
                        </p>
                        
                        <p>
                          MODUNLOAD unloads one or more modules. Not all modules<br /> can be unloaded.
                        </p>
                        
                        <p>
                          The names can be gathered from the MODLIST command. They<br /> are not necessarily equal to the pathnames to load them<br /> with MODLOAD.
                        </p>
                        
                        <p>
                          <strong>Syntax:</strong> <tt>MODUNLOAD <name...></tt>
                        </p>
                        
                        <p>
                          <strong>Example:</strong><br /> <br /><tt>/msg OperServ MODUNLOAD chanserv/register</tt><br /> <a name="NOOP"><br /> <h2>
                            NOOP
                          </h2>
                          
                          <p>
                            </a>
                          </p>
                          
                          <p>
                            NOOP allows you to deny IRCop access on a per-hostmask<br /> or per-server basis. If a matching user opers up, they<br /> will be killed.
                          </p>
                          
                          <p>
                            <strong>Syntax:</strong> <tt>NOOP ADD HOSTMASK <nick!user@host> [reason]</tt><br /> <strong>Syntax:</strong> <tt>NOOP ADD SERVER <mask> [reason]</tt>
                          </p>
                          
                          <p>
                            <strong>Examples:</strong><br /> <br /><tt>/msg OperServ NOOP ADD HOSTMASK *!*@some.spoof Abusive operator</tt><br /> <br /><tt>/msg OperServ NOOP ADD SERVER bad.server Abusive admin</tt>
                          </p>
                          
                          <p>
                            <strong>Syntax:</strong> <tt>NOOP DEL HOSTMASK <nick!user@host></tt><br /> <strong>Syntax:</strong> <tt>NOOP DEL SERVER <mask></tt>
                          </p>
                          
                          <p>
                            <strong>Examples:</strong><br /> <br /><tt>/msg OperServ NOOP DEL HOSTMASK *!some@operator.host</tt><br /> <br /><tt>/msg OperServ NOOP DEL SERVER bad.server</tt>
                          </p>
                          
                          <p>
                            <strong>Syntax:</strong> <tt>NOOP LIST HOSTMASK</tt><br /> <strong>Syntax:</strong> <tt>NOOP LIST SERVER</tt><br /> <a name="OVERRIDE"><br /> <h2>
                              OVERRIDE
                            </h2>
                            
                            <p>
                              </a>
                            </p>
                            
                            <p>
                              OVERRIDE is used for running a command as another user.
                            </p>
                            
                            <p>
                              <strong>Syntax:</strong> <tt>OVERRIDE <target> <service> <command> [params]</tt>
                            </p>
                            
                            <p>
                              <strong>Examples:</strong><br /> <br /><tt>/msg OperServ OVERRIDE dotslasher ChanServ FLAGS #cows nenolod +*</tt><br /> <a name="RAKILL"><br /> <h2>
                                RAKILL
                              </h2>
                              
                              <p>
                                </a>
                              </p>
                              
                              <p>
                                RAKILL allows for regex-based akills,<br /> which are useful for removing clones<br /> or botnets. The akills are not added<br /> to OperServ&#8217;s list and last a week.
                              </p>
                              
                              <p>
                                Be careful, as regex is very easy to<br /> make mistakes with. Use RMATCH first.<br /> The regex syntax is exactly the same.
                              </p>
                              
                              <p>
                                <strong>Syntax:</strong> <tt>RAKILL /<pattern>/[p] <reason></tt>
                              </p>
                              
                              <p>
                                <strong>Example:</strong><br /> <br /><tt>/msg OperServ RAKILL /^m[oo|00]cow/i No moocows allowed.</tt><br /> <a name="READONLY"><br /> <h2>
                                  READONLY
                                </h2>
                                
                                <p>
                                  </a>
                                </p>
                                
                                <p>
                                  READONLY allows services operators to enable<br /> or disable readonly mode while services is<br /> running.
                                </p>
                                
                                <p>
                                  <strong>Syntax:</strong> <tt>READONLY ON|OFF</tt>
                                </p>
                                
                                <p>
                                  <strong>Examples:</strong><br /> <br /><tt>/msg OperServ READONLY ON</tt><br /> <a name="REHASH"><br /> <h2>
                                    REHASH
                                  </h2>
                                  
                                  <p>
                                    </a>
                                  </p>
                                  
                                  <p>
                                    REHASH updates the database and reloads<br /> the configuration file. You can perform<br /> a rehash from system console with a kill -HUP<br /> command.
                                  </p>
                                  
                                  <p>
                                    <strong>Syntax:</strong> <tt>REHASH</tt>
                                  </p>
                                  
                                  <p>
                                    <strong>Example:</strong><br /> <br /><tt>/msg OperServ REHASH</tt><br /> <a name="RESTART"><br /> <h2>
                                      RESTART
                                    </h2>
                                    
                                    <p>
                                      </a>
                                    </p>
                                    
                                    <p>
                                      RESTART shuts down services and restarts them.
                                    </p>
                                    
                                    <p>
                                      <strong>Syntax:</strong> <tt>RESTART</tt>
                                    </p>
                                    
                                    <p>
                                      <strong>Example:</strong><br /> <br /><tt>/msg OperServ RESTART</tt><br /> <a name="RMATCH"><br /> <h2>
                                        RMATCH
                                      </h2>
                                      
                                      <p>
                                        </a>
                                      </p>
                                      
                                      <p>
                                        RMATCH shows all users whose<br /> <u>nick</u>!<u>user</u>@<u>host</u> <u>gecos</u><br /> matches the given regular expression.
                                      </p>
                                      
                                      <p>
                                        Instead of a slash, any character that<br /> is not a letter, digit, whitespace or<br /> backslash and does not occur in the pattern<br /> can be used. An i after the pattern means<br /> case insensitive matching.
                                      </p>
                                      
                                      <p>
                                        By default, the pattern is a POSIX extended<br /> regular expression. If PCRE support has been<br /> compiled in, you can put a p after the pattern<br /> to use it.
                                      </p>
                                      
                                      <p>
                                        By default, there is a limit on the number<br /> of matches. To override this limit, add<br /> the FORCE keyword. In any case the actual<br /> number of matches will be shown.
                                      </p>
                                      
                                      <p>
                                        <strong>Syntax:</strong> <tt>RMATCH /<pattern>/[p] [FORCE]</tt>
                                      </p>
                                      
                                      <p>
                                        <strong>Example:</strong><br /> <br /><tt>/msg OperServ RMATCH /^m(oo|00)cow/i FORCE</tt><br /> <br /><tt>/msg OperServ RMATCH #^[a-z]+!~?[a-z]+@#</tt><br /> <br /><tt>/msg OperServ RMATCH /^[^ ]* [^ ]*$/</tt><br /> <br /><tt>/msg OperServ RMATCH /\d\d\d/p</tt><br /> <a name="RNC"><br /> <h2>
                                          RNC
                                        </h2>
                                        
                                        <p>
                                          </a>
                                        </p>
                                        
                                        <p>
                                          RNC shows the most common realnames on the network.
                                        </p>
                                        
                                        <p>
                                          <strong>Syntax:</strong> <tt>RNC [number]</tt>
                                        </p>
                                        
                                        <p>
                                          <strong>Example:</strong><br /> <br /><tt>/msg OperServ RNC 10</tt><br /> <a name="RWATCH"><br /> <h2>
                                            RWATCH
                                          </h2>
                                          
                                          <p>
                                            </a>
                                          </p>
                                          
                                          <p>
                                            RWATCH maintains a list of regular expressions,<br /> which the <u>nick</u>!<u>user</u>@<u>host</u> <u>gecos</u><br /> of all connecting clients are matched against.<br /> Matching clients can be displayed in the snoop<br /> channel and/or banned from the network. These<br /> network bans are set on *@host, last 24 hours<br /> and are not added to the AKILL list.<br /> The RWATCH list is stored in etc/rwatch.db and<br /> saved whenever it is modified.
                                          </p>
                                          
                                          <p>
                                            See RMATCH for more information about regular<br /> expression syntax.
                                          </p>
                                          
                                          <p>
                                            <strong>Syntax:</strong> <tt>RWATCH ADD /<pattern>/[p] <reason></tt>
                                          </p>
                                          
                                          <p>
                                            Adds a regular expression to the RWATCH list.<br /> The reason is shown in snoop notices and kline reasons.
                                          </p>
                                          
                                          <p>
                                            <strong>Syntax:</strong> <tt>RWATCH DEL /<pattern>/[p]</tt>
                                          </p>
                                          
                                          <p>
                                            Removes a regular expression from the RWATCH list.
                                          </p>
                                          
                                          <p>
                                            <strong>Syntax:</strong> <tt>RWATCH LIST</tt>
                                          </p>
                                          
                                          <p>
                                            Shows the RWATCH list. The meaning of the letters is:<br /> <br /><tt>i - case insensitive match</tt><br /> <br /><tt>p - PCRE pattern</tt><br /> <br /><tt>S - matching clients are shown in the snoop channel</tt><br /> <br /><tt>K - matching clients are banned from the network</tt>
                                          </p>
                                          
                                          <p>
                                            <strong>Syntax:</strong> <tt>RWATCH SET /<pattern>/[p] <options></tt>
                                          </p>
                                          
                                          <p>
                                            Changes the action for a regular expression. Possible<br /> values for <options> are:<br /> <br /><tt>SNOOP - enables display in the snoop channel</tt><br /> <br /><tt>NOSNOOP - disables display in the snoop channel</tt><br /> <br /><tt>KLINE - enables network bans</tt><br /> <br /><tt>NOKLINE - disables network bans</tt>
                                          </p>
                                          
                                          <p>
                                            <strong>Example:</strong><br /> <br /><tt>/msg OperServ RWATCH ADD /^m(oo|00)cow/i moocow figure</tt><br /> <br /><tt>/msg OperServ RWATCH DEL /^m(oo|00)cow/i</tt><br /> <a name="SGLINE"><br /> <h2>
                                              SGLINE
                                            </h2>
                                            
                                            <p>
                                              </a>
                                            </p>
                                            
                                            <p>
                                              SGLINE allows you to maintain network-wide bans by<br /> real name (gecos). It works similarly to AKILL.
                                            </p>
                                            
                                            <p>
                                              <strong>Syntax:</strong> <tt>SGLINE ADD <gecos> [!P|!T <minutes>] <reason></tt>
                                            </p>
                                            
                                            <p>
                                              If the !P token is specified the SGLINE will never expire (permanent).<br /> If the !T token is specified expire time must follow, in minutes,<br /> hours (&#8220;h&#8221;), days (&#8220;d&#8221;) or weeks (&#8220;w&#8221;).
                                            </p>
                                            
                                            <p>
                                              <strong>Examples:</strong><br /> <br /><tt>/msg OperServ SGLINE ADD foo !T 5 bar reason</tt><br /> <br /><tt>/msg OperServ SGLINE ADD foo !T 3d bar reason</tt><br /> <br /><tt>/msg OperServ SGLINE ADD foo !P foo reason</tt><br /> <br /><tt>/msg OperServ SGLINE ADD foo foo reason</tt>
                                            </p>
                                            
                                            <p>
                                              The first example looks for the user with a gecos of &#8220;foo&#8221; and adds<br /> a 5 minute SGLINE for &#8220;bar reason.&#8221;
                                            </p>
                                            
                                            <p>
                                              The second example is similar but adds the SGLINE for 3 days instead of<br /> 5 minutes.
                                            </p>
                                            
                                            <p>
                                              The third example adds a permanent SGLINE on foo for &#8220;foo reason.&#8221;
                                            </p>
                                            
                                            <p>
                                              The fourth example adds a SGLINE on foo for the duration specified<br /> in the configuration file for &#8220;foo reason.&#8221;
                                            </p>
                                            
                                            <p>
                                              <strong>Syntax:</strong> <tt>SGLINE DEL <gecos|number></tt>
                                            </p>
                                            
                                            <p>
                                              If number is specified it correlates with the number on SGLINE LIST.<br /> You may specify multiple numbers by separating with commas.<br /> You may specify a range by using a colon.
                                            </p>
                                            
                                            <p>
                                              <strong>Examples:</strong><br /> <br /><tt>/msg OperServ SGLINE DEL foo</tt><br /> <br /><tt>/msg OperServ SGLINE DEL 5</tt><br /> <br /><tt>/msg OperServ SGLINE DEL 1,2,5,10</tt><br /> <br /><tt>/msg OperServ SGLINE DEL 1:5,7,9:11</tt>
                                            </p>
                                            
                                            <p>
                                              <strong>Syntax:</strong> <tt>SGLINE LIST [FULL]</tt>
                                            </p>
                                            
                                            <p>
                                              If FULL is specified the SGLINE reasons will be shown.
                                            </p>
                                            
                                            <p>
                                              <strong>Examples:</strong><br /> <br /><tt>/msg OperServ SGLINE LIST</tt><br /> <br /><tt>/msg OperServ SGLINE LIST FULL</tt>
                                            </p>
                                            
                                            <p>
                                              <strong>Syntax:</strong> <tt>SGLINE SYNC</tt>
                                            </p>
                                            
                                            <p>
                                              Sends all sglines to all servers. This can be useful in case<br /> services will be down or do not see a user as matching a<br /> certain sgline.<br /> <a name="SHUTDOWN"><br /> <h2>
                                                SHUTDOWN
                                              </h2>
                                              
                                              <p>
                                                </a>
                                              </p>
                                              
                                              <p>
                                                SHUTDOWN shuts down services. Services will<br /> not reconnect or restart.
                                              </p>
                                              
                                              <p>
                                                <strong>Syntax:</strong> <tt>SHUTDOWN</tt>
                                              </p>
                                              
                                              <p>
                                                <strong>Example:</strong><br /> <br /><tt>/msg OperServ SHUTDOWN</tt><br /> <a name="SOPER"><br /> <h2>
                                                  SOPER
                                                </h2>
                                                
                                                <p>
                                                  </a>
                                                </p>
                                                
                                                <p>
                                                  SOPER allows manipulation of services operator privileges.
                                                </p>
                                                
                                                <p>
                                                  SOPER LIST shows all accounts with services operator<br /> privileges, both from the configuration file and<br /> this command. It is similar to /stats o OperServ.
                                                </p>
                                                
                                                <p>
                                                  SOPER LISTCLASS shows all defined oper classes. Use<br /> the SPECS command to view the privileges associated<br /> with an oper class.
                                                </p>
                                                
                                                <p>
                                                  SOPER ADD grants services operator privileges to an<br /> account. The granted privileges are described by an<br /> oper class.
                                                </p>
                                                
                                                <p>
                                                  SOPER DEL removes services operator privileges from<br /> an account.
                                                </p>
                                                
                                                <p>
                                                  SOPER SETPASS sets or clears a password for services<br /> operator privileges on an account. The password must<br /> be already encrypted. The target user needs to enter<br /> the password using IDENTIFY.
                                                </p>
                                                
                                                <p>
                                                  It is not possible to modify accounts with<br /> operator{} blocks in the configuration file.
                                                </p>
                                                
                                                <p>
                                                  <strong>Syntax:</strong> <tt>SOPER LIST|LISTCLASS</tt><br /> <strong>Syntax:</strong> <tt>SOPER ADD <account> <operclass></tt><br /> <strong>Syntax:</strong> <tt>SOPER DEL <account></tt><br /> <strong>Syntax:</strong> <tt>SOPER SETPASS <account> [password]</tt>
                                                </p>
                                                
                                                <p>
                                                  <strong>Examples:</strong><br /> <br /><tt>/msg OperServ SOPER LIST</tt><br /> <br /><tt>/msg OperServ SOPER ADD anoper sra</tt><br /> <br /><tt>/msg OperServ SOPER DEL abusiveoper</tt><br /> <br /><tt>/msg OperServ SOPER SETPASS anoper $1$vHFzU0jC$ePfKvERVwaDRdnHOnZZ6h.</tt><br /> <a name="SPECS"><br /> <h2>
                                                    SPECS
                                                  </h2>
                                                  
                                                  <p>
                                                    </a>
                                                  </p>
                                                  
                                                  <p>
                                                    SPECS shows the privileges you have in services.
                                                  </p>
                                                  
                                                  <p>
                                                    <strong>Syntax:</strong> <tt>SPECS</tt>
                                                  </p>
                                                  
                                                  <p>
                                                    It is also possible to see the privileges of other<br /> online users or of oper classes.
                                                  </p>
                                                  
                                                  <p>
                                                    <strong>Syntax:</strong> <tt>SPECS USER <nick></tt><br /> <strong>Syntax:</strong> <tt>SPECS OPERCLASS <classname></tt>
                                                  </p>
                                                  
                                                  <p>
                                                    <strong>Example:</strong><br /> <br /><tt>/msg OperServ SPECS USER w00t</tt><br /> <a name="SQLINE"><br /> <h2>
                                                      SQLINE
                                                    </h2>
                                                    
                                                    <p>
                                                      </a>
                                                    </p>
                                                    
                                                    <p>
                                                      SQLINE allows you to deny the use of certain nicknames<br /> or channels network-wide.
                                                    </p>
                                                    
                                                    <p>
                                                      A nickname sqline may contain *, ?, # (any digit) and<br /> @ (any letter) wildcards. A channel sqline must be an<br /> exact match, starting with # or &.
                                                    </p>
                                                    
                                                    <p>
                                                      <strong>Syntax:</strong> <tt>SQLINE ADD <mask> [!P|!T <minutes>] <reason></tt>
                                                    </p>
                                                    
                                                    <p>
                                                      If the !P token is specified the SQLINE will never expire (permanent).<br /> If the !T token is specified expire time must follow, in minutes,<br /> hours (&#8220;h&#8221;), days (&#8220;d&#8221;) or weeks (&#8220;w&#8221;).
                                                    </p>
                                                    
                                                    <p>
                                                      <strong>Examples:</strong><br /> <br /><tt>/msg OperServ SQLINE ADD spambot* !T 7d bar reason</tt><br /> <br /><tt>/msg OperServ SQLINE ADD spam??? !P foo reason</tt>
                                                    </p>
                                                    
                                                    <p>
                                                      The first example denies the use of nicknames starting with<br /> &#8220;spambot&#8221; for 7 days.
                                                    </p>
                                                    
                                                    <p>
                                                      The second example adds a permanent SQLINE on &#8220;spam???&#8221; for &#8220;foo reason.&#8221;
                                                    </p>
                                                    
                                                    <p>
                                                      <strong>Syntax:</strong> <tt>SQLINE DEL <mask|number></tt>
                                                    </p>
                                                    
                                                    <p>
                                                      If number is specified it correlates with the number on SQLINE LIST.<br /> You may specify multiple numbers by separating with commas.<br /> You may specify a range by using a colon.
                                                    </p>
                                                    
                                                    <p>
                                                      <strong>Examples:</strong><br /> <br /><tt>/msg OperServ SQLINE DEL foo</tt><br /> <br /><tt>/msg OperServ SQLINE DEL 5</tt><br /> <br /><tt>/msg OperServ SQLINE DEL 1,2,5,10</tt><br /> <br /><tt>/msg OperServ SQLINE DEL 1:5,7,9:11</tt>
                                                    </p>
                                                    
                                                    <p>
                                                      <strong>Syntax:</strong> <tt>SQLINE LIST [FULL]</tt>
                                                    </p>
                                                    
                                                    <p>
                                                      If FULL is specified the SQLINE reasons will be shown.
                                                    </p>
                                                    
                                                    <p>
                                                      <strong>Examples:</strong><br /> <br /><tt>/msg OperServ SQLINE LIST</tt><br /> <br /><tt>/msg OperServ SQLINE LIST FULL</tt>
                                                    </p>
                                                    
                                                    <p>
                                                      <strong>Syntax:</strong> <tt>SQLINE SYNC</tt>
                                                    </p>
                                                    
                                                    <p>
                                                      Sends all sqlines to all servers. This is useful because<br /> sqlines must be present before the nickname or channel<br /> is tried to be fully effective.<br /> <a name="UPDATE"><br /> <h2>
                                                        UPDATE
                                                      </h2>
                                                      
                                                      <p>
                                                        </a>
                                                      </p>
                                                      
                                                      <p>
                                                        UPDATE flushes the database to disk.
                                                      </p>
                                                      
                                                      <p>
                                                        <strong>Syntax:</strong> <tt>UPDATE</tt>
                                                      </p>
                                                      
                                                      <p>
                                                        <strong>Example:</strong><br /> <br /><tt>/msg OperServ UPDATE</tt><br /> <a name="UPTIME"><br /> <h2>
                                                          UPTIME
                                                        </h2>
                                                        
                                                        <p>
                                                          </a>
                                                        </p>
                                                        
                                                        <p>
                                                          UPTIME shows services uptime and the number of<br /> registered nicks and channels.
                                                        </p>
                                                        
                                                        <p>
                                                          <strong>Syntax:</strong> <tt>UPTIME</tt>
                                                        </p>