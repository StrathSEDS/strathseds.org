---
title: InfoServ
author: MrRandom
layout: page
---
<a name="DEL"><br /> <h2>
  DEL
</h2>

<p>
  </a>
</p>

<p>
  DEL is used to delete informational messages that you no longer<br /> want users to see on connect. This will not allow you to delete<br /> oper InfoServ messages.
</p>

<p>
  <strong>Syntax:</strong> <tt>DEL <id></tt>
</p>

<p>
  <strong>Example:</strong><br /> <br /><tt>/msg InfoServ DEL 1</tt><br /> <a name="LIST"><br /> <h2>
    LIST
  </h2>
  
  <p>
    </a>
  </p>
  
  <p>
    LIST allows you to view all informational messages in the database.<br /> These messages will also be sent to all users on connect.
  </p>
  
  <p>
    <strong>Syntax:</strong> <tt>LIST</tt>
  </p>
  
  <p>
    <strong>Example:</strong><br /> <br /><tt>/msg InfoServ LIST</tt><br /> <a name="ODEL"><br /> <h2>
      ODEL
    </h2>
    
    <p>
      </a>
    </p>
    
    <p>
      ODEL is used to delete informational messages that you no longer<br /> want opers to see upon oper-up. This will not allow you to delete<br /> user InfoServ messages.
    </p>
    
    <p>
      <strong>Syntax:</strong> <tt>ODEL <id></tt>
    </p>
    
    <p>
      <strong>Example:</strong><br /> <br /><tt>/msg InfoServ ODEL 1</tt><br /> <a name="OLIST"><br /> <h2>
        OLIST
      </h2>
      
      <p>
        </a>
      </p>
      
      <p>
        LIST allows you to view all oper informational messages in the database.<br /> These messages will also be sent to all opers upon oper-up.<br /> This command will not list user informational messages, use LIST for that.
      </p>
      
      <p>
        <strong>Syntax:</strong> <tt>OLIST</tt>
      </p>
      
      <p>
        <strong>Example:</strong><br /> <br /><tt>/msg InfoServ OLIST</tt><br /> <a name="POST"><br /> <h2>
          POST
        </h2>
        
        <p>
          </a>
        </p>
        
        <p>
          POST allows you to post one-time messages to all users (that will be sent when<br /> you run the command) or messages that all users will see upon connect or<br /> messages only opers will see when they oper-up.
        </p>
        
        <p>
          Underscores (&#8220;_&#8221;) in the subject will be replaced by spaces.
        </p>
        
        <p>
          IMPORTANCE:<br /> <br /><tt>Importance defines the type of message that will be sent.</tt>
        </p>
        
        <p>
          <br /><tt>0 - Only display to opers upon oper-up.</tt><br /> <br /><tt>1 - Only display to users upon connect.</tt><br /> <br /><tt>2 - Send a notice to all users now.</tt><br /> <br /><tt>3 - Display message to all users upon connect AND send a notice to</tt><br /> <br /><tt> all users now.</tt><br /> <br /><tt>4 - Send a privmsg/query to all users now. It is important to note that this</tt><br /> <br /><tt> may annoy users and should only be used when absolutely necessary.</tt>
        </p>
        
        <p>
          <p>
            <strong>Syntax:</strong> <tt>POST <importance> <subject> <message></tt>
          </p>
          
          <p>
            <strong>Example:</strong><br /> <br /><tt>/msg InfoServ POST 2 Info1 Some important information for users.</tt><br /> <br /><tt>/msg InfoServ POST 1 Multi_Word_Subject Some more information.</tt>
          </p>