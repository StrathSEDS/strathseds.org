---
title: IRC Commands
author: MrRandom
layout: page
---
This section gives you details about all of the commands available on DgitalIRC. It is broken down into commands available to users and services admins, for each service.

&nbsp;

*   [NickServ Commands][1]
*   [ChanServ Commands][2]
*   [HostServ Commands][3]
*   [Fantasy Commands][4]
*   [BotServ Commands][5]
*   [MemoServ Commands][6]
*   [OperServ][7]
*   [User Commands][8]
*   [IRCOp Commands][9]
*   [Modes][10]

 [1]: http://www.digitalirc.org/commands/nickserv/ "NickServ"
 [2]: http://www.digitalirc.org/commands/chanserv/ "ChanServ"
 [3]: http://www.digitalirc.org/commands/hostserv/ "HostServ"
 [4]: http://www.digitalirc.org/commands/fantasy/ "Fantasy Commands"
 [5]: http://www.digitalirc.org/commands/botserv/ "BotServ"
 [6]: http://www.digitalirc.org/commands/memoserv/ "MemoServ"
 [7]: http://www.digitalirc.org/commands/operserv/ "OperServ"
 [8]: http://www.digitalirc.org/commands/user-commands/ "User Commands"
 [9]: http://www.digitalirc.org/commands/ircop-command/ "IRC Operator Commands"
 [10]: http://www.digitalirc.org/commands/modes/ "Modes"