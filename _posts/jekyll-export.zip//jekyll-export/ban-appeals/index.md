---
title: Ban appeals.
author: MrRandom
layout: page
---
<p>This page has been moved <a href="http://www.digitalirc.org/wiki/index.php?title=Network_bans">here </a></p>
<p><a href="http://www.digitalirc.org/wiki/index.php?title=Network_bans">(http://www.digitalirc.org/wiki/index.php?title=Network_bans)</p>
<p></a></p>
