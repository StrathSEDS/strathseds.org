---
title: Welcome PinkFloyd to the IRC Network
author: MrRandom
layout: post
permalink: /blog/2012/12/03/welcome-pinkfloyd-to-the-irc-network/
categories:
  - Informational
tags:
  - floyd
  - pink
  - pinkfloyd
  - servers
  - services
---
Hey,

A new server has been linked to the network pinkfloyd.digitalirc.org it is admin&#8217;ed by thetammy0r. It is based in West Coast of North America and supports the standard SSL port of 6697 and IPv6 connections.

-MrR

&nbsp;