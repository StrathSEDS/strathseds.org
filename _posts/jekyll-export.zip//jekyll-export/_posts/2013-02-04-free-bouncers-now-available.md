---
title: Free bouncers now available
author: MrRandom
layout: post
permalink: /blog/2013/02/04/free-bouncers-now-available/
categories:
  - Informational
---
Hey,

To get one simply join #bnc and follow the instructions in the topic. You must have had a registered nickname for at least 14 days and have no previous bans.

-MrR