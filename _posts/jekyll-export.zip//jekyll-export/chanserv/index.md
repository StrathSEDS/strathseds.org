---
title: ChanServ
author: MrRandom
layout: page
---
# ChanServ

<a name="ACCESS ADD"><br /> <h2>
  ACCESS ADD
</h2>

<p>
  </a>
</p>

<p>
  ACCESS ADD will assign the given user to the given<br /> channel role.
</p>

<p>
  <strong>Syntax:</strong> <tt>ACCESS <#channel> ADD <user> <role></tt>
</p>

<p>
  <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ ACCESS #atheme ADD stitch helpers</tt><br /> <a name="ACCESS DEL"><br /> <h2>
    ACCESS DEL
  </h2>
  
  <p>
    </a>
  </p>
  
  <p>
    ACCESS DEL will remove all channel access from a given user.
  </p>
  
  <p>
    <strong>Syntax:</strong> <tt>ACCESS <#channel> DEL <user></tt>
  </p>
  
  <p>
    <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ ACCESS #atheme DEL stitch</tt><br /> <a name="ACCESS INFO"><br /> <h2>
      ACCESS INFO
    </h2>
    
    <p>
      </a>
    </p>
    
    <p>
      ACCESS INFO displays what level of access a given user has<br /> in a given channel. It will display role, long-form flags<br /> and short-form flags along with the last date the user&#8217;s<br /> access was modified.
    </p>
    
    <p>
      <strong>Syntax:</strong> <tt>ACCESS <#channel> INFO <user></tt>
    </p>
    
    <p>
      <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ ACCESS #atheme INFO nenolod</tt><br /> <a name="ACCESS LIST"><br /> <h2>
        ACCESS LIST
      </h2>
      
      <p>
        </a>
      </p>
      
      <p>
        ACCESS LIST lists all users with channel access and their<br /> roles in the channel. It uses fuzzy matching so if a user<br /> does not exactly match any role, they will be listed as<br /> the closest role they match.
      </p>
      
      <p>
        <strong>Syntax:</strong> <tt>ACCESS <#channel> LIST</tt>
      </p>
      
      <p>
        <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ ACCESS #atheme LIST</tt><br /> <a name="ACCESS SET"><br /> <h2>
          ACCESS SET
        </h2>
        
        <p>
          </a>
        </p>
        
        <p>
          ACCESS SET allows you to set specific flags on a user<br /> above or below a certain role or lets you change the<br /> role a user is in. Multiple flags should be seperated<br /> by a space and have the modifier (+ or -) in front<br /> of each flag.
        </p>
        
        <p>
          <strong>Syntax:</strong> <tt>ACCESS <#channel> SET <user> <role|flags></tt>
        </p>
        
        <p>
          Flags:<br /> <br /><tt>+voice - Enables use of the voice/devoice commands.</tt><br /> <br /><tt>+autovoice - Enables automatic voice.</tt><br /> <br /><tt>+halfop - Enables use of the halfop/dehalfop commands.</tt><br /> <br /><tt>+autohalfop - Enables automatic halfop.</tt><br /> <br /><tt>+op - Enables use of the op/deop commands.</tt><br /> <br /><tt>+autoop - Enables automatic op.</tt><br /> <br /><tt>+protect - Enables use of the protect/deprotect commands.</tt><br /> <br /><tt>+owner - Enables use of the owner/deowner commands.</tt><br /> <br /><tt>+set - Enables use of the set command.</tt><br /> <br /><tt>+invite - Enables use of the invite and getkey commands.</tt><br /> <br /><tt>+remove - Enables use of the kick, kickban, ban and unban commands.</tt><br /> <br /><tt>+remove - Enables use of the ban and unban commands.</tt><br /> <br /><tt>+remove - Enables use of the unban command.</tt><br /> <br /><tt>+recover - Enables use of the recover and clear commands.</tt><br /> <br /><tt>+acl-change - Enables modification of channel access lists.</tt><br /> <br /><tt>+topic - Enables use of the topic and topicappend commands.</tt><br /> <br /><tt>+acl-view - Enables viewing of channel access lists.</tt><br /> <br /><tt>+successor - Marks the user as a successor.</tt><br /> <br /><tt>+founder - Grants full founder access.</tt><br /> <br /><tt>+banned - Enables automatic kickban.</tt>
        </p>
        
        <p>
          <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ ACCESS #atheme SET stitch channel-ops</tt><br /> <br /><tt>/msg ChanServ ACCESS #atheme SET stitch -topic</tt><br /> <br /><tt>/msg ChanServ ACCESS #foo set jdhore +acl-view +topic +autoop</tt><br /> <a name="AKICK"><br /> <h2>
            AKICK
          </h2>
          
          <p>
            </a>
          </p>
          
          <p>
            The AKICK command allows you to maintain channel<br /> ban lists. Users on the AKICK list will be<br /> automatically kickbanned when they join the channel,<br /> removing any matching ban exceptions first. Users<br /> with the +r flag are exempt.
          </p>
          
          <p>
            <strong>Syntax:</strong> <tt>AKICK <#channel> ADD <nickname|hostmask> [!P|!T <minutes>] [reason]</tt>
          </p>
          
          <p>
            You may also specify a hostmask (nick!user@host)<br /> for the AKICK list.
          </p>
          
          <p>
            The reason is used when kicking and is visible in<br /> AKICK LIST. If the reason contains a &#8216;|&#8217; character,<br /> everything after it does not appear in kick reasons<br /> but does appear in AKICK LIST.
          </p>
          
          <p>
            If the !P token is specified, the AKICK will never<br /> expire (permanent). If the !T token is specified, expire<br /> time must follow, in minutes, hours (&#8220;h&#8221;), days (&#8220;d&#8221;)<br /> or weeks (&#8220;w&#8221;).
          </p>
          
          <p>
            <strong>Syntax:</strong> <tt>AKICK <#channel> DEL <nickname|hostmask></tt>
          </p>
          
          <p>
            This will remove an entry from the AKICK list. Removing<br /> an entry will remove any matching channel bans unless the<br /> channel is set NOSYNC.
          </p>
          
          <p>
            <strong>Syntax:</strong> <tt>AKICK <#channel> LIST</tt>
          </p>
          
          <p>
            This will list all entries in the AKICK list, including<br /> the reason and time left until expiration.
          </p>
          
          <p>
            <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ AKICK #foo ADD bar you are annoying | private op info</tt><br /> <br /><tt>/msg ChanServ AKICK #foo ADD *!*foo@bar.com !T 5d</tt><br /> <br /><tt>/msg ChanServ AKICK #foo DEL bar</tt><br /> <br /><tt>/msg ChanServ AKICK #foo LIST</tt><br /> <a name="BAN"><br /> <h2>
              BAN
            </h2>
            
            <p>
              </a>
            </p>
            
            <p>
              The BAN command allows you to ban a user or hostmask from<br /> a channel.
            </p>
            
            <p>
              <strong>Syntax:</strong> <tt>BAN <#channel> <nickname|hostmask></tt>
            </p>
            
            <p>
              <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ BAN #chat carnell</tt><br /> <br /><tt>/msg ChanServ BAN #chat *!*@*.ipt.aol.com</tt><br /> <a name="CLEAR BANS"><br /> <h2>
                CLEAR BANS
              </h2>
              
              <p>
                </a>
              </p>
              
              <p>
                Clear bans will remove all bans found in a specific<br /> channel. If your ircd supports other lists associated<br /> with a channel (e.g. ban exceptions), you can clear<br /> these by specifying the mode letters. Specify an<br /> asterisk to clear all lists.
              </p>
              
              <p>
                <strong>Syntax:</strong> <tt>CLEAR <#channel> BANS [types]</tt>
              </p>
              
              <p>
                <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ CLEAR #support BANS</tt>
              </p>
              
              <p>
                Clears #support ban list.
              </p>
              
              <p>
                <br /><tt>/msg ChanServ CLEAR #support BANS eI</tt>
              </p>
              
              <p>
                Removes all ban and invite exceptions on #support<br /> (if your ircd supports them).
              </p>
              
              <p>
                <br /><tt>/msg ChanServ CLEAR #support BANS *</tt>
              </p>
              
              <p>
                Clears all lists of #support.
              </p>
              
              <p>
                <br /><tt>/msg ChanServ CLEAR #support BANS +</tt>
              </p>
              
              <p>
                Shows the possible letters.<br /> <a name="CLEAR FLAGS"><br /> <h2>
                  CLEAR FLAGS
                </h2>
                
                <p>
                  </a>
                </p>
                
                <p>
                  CLEAR FLAGS will kick remove all flags from all users<br /> (or groups) with channel access on the channel specified<br /> except for users who are channel founders.
                </p>
                
                <p>
                  This command can only be used by channel founders.
                </p>
                
                <p>
                  <strong>Syntax:</strong> <tt>CLEAR <#channel> FLAGS</tt>
                </p>
                
                <p>
                  <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ CLEAR #atheme FLAGS</tt><br /> <a name="CLEAR USERS"><br /> <h2>
                    CLEAR USERS
                  </h2>
                  
                  <p>
                    </a>
                  </p>
                  
                  <p>
                    Clear users will kick all users out of the channel,<br /> except you. The channel will be cycled (recreated)<br /> if you are not on it.
                  </p>
                  
                  <p>
                    If a reason is specified, it will be included in the<br /> kick message.
                  </p>
                  
                  <p>
                    <strong>Syntax:</strong> <tt>CLEAR <#channel> USERS [reason]</tt>
                  </p>
                  
                  <p>
                    <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ CLEAR #ChatZone USERS</tt><br /> <a name="CLOSE"><br /> <h2>
                      CLOSE
                    </h2>
                    
                    <p>
                      </a>
                    </p>
                    
                    <p>
                      CLOSE prevents a channel from being used. Anyone<br /> who enters is immediately kickbanned. The channel<br /> cannot be dropped and foundership cannot be<br /> transferred.
                    </p>
                    
                    <p>
                      Enabling CLOSE will immediately kick all<br /> users from the channel.
                    </p>
                    
                    <p>
                      Use CLOSE OFF to reopen a channel. While closed,<br /> channels will still expire.
                    </p>
                    
                    <p>
                      <strong>Syntax:</strong> <tt>CLOSE <#channel> ON|OFF [reason]</tt>
                    </p>
                    
                    <p>
                      <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ CLOSE #lamers ON spamming</tt><br /> <br /><tt>/msg ChanServ CLOSE #spiderslair OFF</tt><br /> <a name="DROP"><br /> <h2>
                        DROP
                      </h2>
                      
                      <p>
                        </a>
                      </p>
                      
                      <p>
                        DROP allows you to &#8220;unregister&#8221; a registered channel.
                      </p>
                      
                      <p>
                        Once you DROP a channel all of the data associated<br /> with it (access lists, etc) are removed and cannot<br /> be restored.
                      </p>
                      
                      <p>
                        See help on SET FOUNDER and FLAGS for transferring<br /> a channel to another user.
                      </p>
                      
                      <p>
                        <strong>Syntax:</strong> <tt>DROP <#channel></tt>
                      </p>
                      
                      <p>
                        <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ DROP #foo</tt><br /> <a name="FDROP"><br /> <h2>
                          FDROP
                        </h2>
                        
                        <p>
                          </a>
                        </p>
                        
                        <p>
                          FDROP allows dropping any registered channel,<br /> provided it is not set held (see help on HOLD).
                        </p>
                        
                        <p>
                          Once you FDROP a channel all of the data associated<br /> with it (access lists, etc) are removed and cannot<br /> be restored.
                        </p>
                        
                        <p>
                          <strong>Syntax:</strong> <tt>FDROP <#channel></tt>
                        </p>
                        
                        <p>
                          <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ FDROP #foo</tt><br /> <a name="FLAGS"><br /> <h2>
                            FLAGS
                          </h2>
                          
                          <p>
                            </a>
                          </p>
                          
                          <p>
                            The FLAGS command allows for the granting/removal of channel<br /> privileges on a more specific, non-generalized level. It<br /> supports nicknames, groups and hostmasks as targets.
                          </p>
                          
                          <p>
                            When only the channel argument is given, a listing of<br /> permissions granted to users will be displayed.
                          </p>
                          
                          <p>
                            <strong>Syntax:</strong> <tt>FLAGS <#channel></tt>
                          </p>
                          
                          <p>
                            Otherwise, an access entry is modified. A modification may be<br /> specified by a template name (changes the access to the<br /> template) or a flags change (starts with + or -). See the<br /> TEMPLATE help entry for more information about templates.
                          </p>
                          
                          <p>
                            If you are not a founder, you may only manipulate flags you<br /> have yourself, and may not edit users that have flags you<br /> don&#8217;t have. For this purpose, +v grants +V, +o grants +O<br /> and +r grants +b.<br /> If you are not a founder, you may only manipulate flags you<br /> have yourself, and may not edit users that have flags you<br /> don&#8217;t have. For this purpose, +v grants +V, +h grants +H,<br /> +o grants +O and +r grants +b.
                          </p>
                          
                          <p>
                            If the LIMITFLAGS option is set for the channel, this is<br /> restricted further, see help for SET LIMITFLAGS.
                          </p>
                          
                          <p>
                            If you do not have +f you may still remove your own access<br /> with -*.
                          </p>
                          
                          <p>
                            <strong>Syntax:</strong> <tt>FLAGS <#channel> [nickname|hostmask|group template]</tt><br /> <strong>Syntax:</strong> <tt>FLAGS <#channel> [nickname|hostmask|group flag_changes]</tt>
                          </p>
                          
                          <p>
                            Permissions:<br /> <br /><tt>+v - Enables use of the voice/devoice commands.</tt><br /> <br /><tt>+V - Enables automatic voice.</tt><br /> <br /><tt>+h - Enables use of the halfop/dehalfop commands.</tt><br /> <br /><tt>+H - Enables automatic halfop.</tt><br /> <br /><tt>+o - Enables use of the op/deop commands.</tt><br /> <br /><tt>+O - Enables automatic op.</tt><br /> <br /><tt>+a - Enables use of the protect/deprotect commands.</tt><br /> <br /><tt>+q - Enables use of the owner/deowner commands.</tt><br /> <br /><tt>+s - Enables use of the set command.</tt><br /> <br /><tt>+i - Enables use of the invite and getkey commands.</tt><br /> <br /><tt>+r - Enables use of the kick, kickban, ban and unban commands.</tt><br /> <br /><tt>+r - Enables use of the ban and unban commands.</tt><br /> <br /><tt>+r - Enables use of the unban command.</tt><br /> <br /><tt>+R - Enables use of the recover and clear commands.</tt><br /> <br /><tt>+f - Enables modification of channel access lists.</tt><br /> <br /><tt>+t - Enables use of the topic and topicappend commands.</tt><br /> <br /><tt>+A - Enables viewing of channel access lists.</tt><br /> <br /><tt>+S - Marks the user as a successor.</tt><br /> <br /><tt>+F - Grants full founder access.</tt><br /> <br /><tt>+b - Enables automatic kickban.</tt>
                          </p>
                          
                          <p>
                            The special permission +* adds all permissions except +b and +F.<br /> The special permission -* removes all permissions including +b and +F.
                          </p>
                          
                          <p>
                            <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ FLAGS #foo</tt><br /> <br /><tt>/msg ChanServ FLAGS #foo foo!*@bar.com VOP</tt><br /> <br /><tt>/msg ChanServ FLAGS #foo foo!*@bar.com -V+oO</tt><br /> <br /><tt>/msg ChanServ FLAGS #foo foo!*@bar.com -*</tt><br /> <br /><tt>/msg ChanServ FLAGS #foo foo +oOtsi</tt><br /> <br /><tt>/msg ChanServ FLAGS #foo TroubleUser!*@*.troubleisp.net +b</tt><br /> <br /><tt>/msg ChanServ FLAGS #foo !baz +*</tt><br /> <a name="FTRANSFER"><br /> <h2>
                              FTRANSFER
                            </h2>
                            
                            <p>
                              </a>
                            </p>
                            
                            <p>
                              FTRANSFER forcefully transfers foundership<br /> of a channel.
                            </p>
                            
                            <p>
                              <strong>Syntax:</strong> <tt>FTRANSFER <#channel> <founder></tt>
                            </p>
                            
                            <p>
                              <strong>Example:</strong><br /> <br /><tt>/msg ChanServ FTRANSFER #casual vodkaswirl</tt><br /> <a name="GETKEY"><br /> <h2>
                                GETKEY
                              </h2>
                              
                              <p>
                                </a>
                              </p>
                              
                              <p>
                                GETKEY returns the key (+k, password to be allowed in)<br /> of the specified channel: /join #channel key
                              </p>
                              
                              <p>
                                <strong>Syntax:</strong> <tt>GETKEY <#channel></tt>
                              </p>
                              
                              <p>
                                <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ GETKEY #foo</tt><br /> <a name="HALFOP|DEHALFOP"><br /> <h2>
                                  HALFOP|DEHALFOP
                                </h2>
                                
                                <p>
                                  </a>
                                </p>
                                
                                <p>
                                  These commands perform status mode changes on a channel.
                                </p>
                                
                                <p>
                                  If you perform an operation on another user, they will be<br /> notified that you did it.
                                </p>
                                
                                <p>
                                  If the last parameter is omitted the action is performed<br /> on the person requesting the command.
                                </p>
                                
                                <p>
                                  <strong>Syntax:</strong> <tt>HALFOP|DEHALFOP <#channel> [nickname]</tt>
                                </p>
                                
                                <p>
                                  <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ HALFOP #foo</tt><br /> <a name="HOLD"><br /> <h2>
                                    HOLD
                                  </h2>
                                  
                                  <p>
                                    </a>
                                  </p>
                                  
                                  <p>
                                    HOLD prevents a channel from expiring for inactivity.<br /> Held channels will still expire when there are no<br /> eligible successors.
                                  </p>
                                  
                                  <p>
                                    <strong>Syntax:</strong> <tt>HOLD <#channel> ON|OFF</tt>
                                  </p>
                                  
                                  <p>
                                    <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ HOLD #atheme ON</tt><br /> <a name="INFO"><br /> <h2>
                                      INFO
                                    </h2>
                                    
                                    <p>
                                      </a>
                                    </p>
                                    
                                    <p>
                                      INFO displays channel information such as<br /> registration time, flags, and other details.
                                    </p>
                                    
                                    <p>
                                      <strong>Syntax:</strong> <tt>INFO <#channel></tt>
                                    </p>
                                    
                                    <p>
                                      <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ INFO #foo</tt><br /> <a name="INVITE"><br /> <h2>
                                        INVITE
                                      </h2>
                                      
                                      <p>
                                        </a>
                                      </p>
                                      
                                      <p>
                                        INVITE requests services to invite you to the<br /> specified channel. This is useful if you use<br /> the +i channel mode.
                                      </p>
                                      
                                      <p>
                                        <strong>Syntax:</strong> <tt>INVITE <#channel></tt>
                                      </p>
                                      
                                      <p>
                                        <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ INVITE #foo</tt><br /> <a name="KICK"><br /> <h2>
                                          KICK
                                        </h2>
                                        
                                        <p>
                                          </a>
                                        </p>
                                        
                                        <p>
                                          The KICK command allows for the removal of a user from<br /> a channel. The user can immediately rejoin.
                                        </p>
                                        
                                        <p>
                                          Your nick will be added to the kick reason.
                                        </p>
                                        
                                        <p>
                                          <strong>Syntax:</strong> <tt>KICK <#channel> <nick> [reason]</tt>
                                        </p>
                                        
                                        <p>
                                          <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ KICK #foo abuser</tt><br /> <br /><tt>/msg ChanServ KICK #foo abuser please stop</tt><br /> <a name="KICKBAN"><br /> <h2>
                                            KICKBAN
                                          </h2>
                                          
                                          <p>
                                            </a>
                                          </p>
                                          
                                          <p>
                                            The KICKBAN command allows for the removal of a user from<br /> a channel while placing a ban on the user.
                                          </p>
                                          
                                          <p>
                                            Any matching ban exceptions will be removed.
                                          </p>
                                          
                                          <p>
                                            <strong>Syntax:</strong> <tt>KICKBAN <#channel> <nick> [reason]</tt>
                                          </p>
                                          
                                          <p>
                                            <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ KICKBAN #foo abuser</tt><br /> <br /><tt>/msg ChanServ KICKBAN #foo abuser go away</tt><br /> <a name="LIST"><br /> <h2>
                                              LIST
                                            </h2>
                                            
                                            <p>
                                              </a>
                                            </p>
                                            
                                            <p>
                                              LIST shows channels that match a given criteria.<br /> Multiple criteria may be used in the same command.
                                            </p>
                                            
                                            <p>
                                              Current Criteria are:<br /> PATTERN &#8211; All channels that match a given pattern.<br /> MARK-REASON &#8211; All channels whose mark reason matches<br /> <br /><tt> a given pattern.</tt><br /> CLOSE-REASON &#8211; All channels which are closed whose close<br /> <br /><tt> reason matches a given pattern.</tt><br /> HOLD &#8211; All channels with the HOLD flag set.<br /> NOOP &#8211; All channels with the NOOP flag set.<br /> LIMITFLAGS &#8211; All channels with the LIMITFLAGS flag set.<br /> SECURE &#8211; All channels with the SECURE flag set.<br /> VERBOSE &#8211; All channels with the VERBOSE flag set.<br /> RESTRICTED &#8211; All channels with the RESTRICTED flag set.<br /> KEEPTOPIC &#8211; All channels with the KEEPTOPIC flag set.<br /> VERBOSE-OPS &#8211; All channels set to only be verbose to ops.<br /> TOPICLOCK &#8211; All channels with the TOPICLOCK flag set.<br /> GUARD &#8211; All channels with the GUARD flag set.<br /> PRIVATE &#8211; All channels with the PRIVATE flag set.
                                            </p>
                                            
                                            <p>
                                              CLOSED &#8211; All channels closed by network staff.<br /> MARKED &#8211; All channels marked by network staff.<br /> ACLSIZE &#8211; Channels with an access list larger than a given size.<br /> REGISTERED &#8211; Channels registered longer ago than a given age.<br /> LASTUSED &#8211; Channels last used longer ago than a given age.
                                            </p>
                                            
                                            <p>
                                              <strong>Syntax:</strong> <tt>LIST <criteria></tt>
                                            </p>
                                            
                                            <p>
                                              <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ LIST pattern #*foo*</tt><br /> <br /><tt>/msg ChanServ LIST hold</tt><br /> <br /><tt>/msg ChanServ LIST closed pattern #x*</tt><br /> <br /><tt>/msg ChanServ LIST aclsize 10</tt><br /> <br /><tt>/msg ChanServ LIST registered 30d</tt><br /> <br /><tt>/msg ChanServ LIST aclsize 20 registered 7d pattern #bar*</tt><br /> <br /><tt>/msg ChanServ LIST mark-reason lamers?here</tt><br /> <a name="MARK"><br /> <h2>
                                                MARK
                                              </h2>
                                              
                                              <p>
                                                </a>
                                              </p>
                                              
                                              <p>
                                                MARK allows operators to attach a note to a channel.<br /> For example, an operator could mark the channel of a<br /> spammer so that others know it has previously been<br /> warned.
                                              </p>
                                              
                                              <p>
                                                MARK information will be displayed in INFO output.
                                              </p>
                                              
                                              <p>
                                                <strong>Syntax:</strong> <tt>MARK <#channel> ON|OFF <reason></tt>
                                              </p>
                                              
                                              <p>
                                                <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ MARK #lobby ON Takeover: returned to bill</tt><br /> <a name="OP|DEOP|VOICE|DEVOICE"><br /> <h2>
                                                  OP|DEOP|VOICE|DEVOICE
                                                </h2>
                                                
                                                <p>
                                                  </a>
                                                </p>
                                                
                                                <p>
                                                  These commands perform status mode changes on a channel.
                                                </p>
                                                
                                                <p>
                                                  If you perform an operation on another user, they will be<br /> notified that you did it.
                                                </p>
                                                
                                                <p>
                                                  If the last parameter is omitted the action is performed<br /> on the person requesting the command.
                                                </p>
                                                
                                                <p>
                                                  <strong>Syntax:</strong> <tt>OP|DEOP <#channel> [nickname]</tt><br /> <strong>Syntax:</strong> <tt>VOICE|DEVOICE <#channel> [nickname]</tt>
                                                </p>
                                                
                                                <p>
                                                  <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ OP #foo bar</tt><br /> <br /><tt>/msg ChanServ DEVOICE #foo</tt><br /> <a name="OWNER|DEOWNER"><br /> <h2>
                                                    OWNER|DEOWNER
                                                  </h2>
                                                  
                                                  <p>
                                                    </a>
                                                  </p>
                                                  
                                                  <p>
                                                    These commands perform status mode changes on a channel.
                                                  </p>
                                                  
                                                  <p>
                                                    If you perform an operation on another user, they will be<br /> notified that you did it.
                                                  </p>
                                                  
                                                  <p>
                                                    If the last parameter is omitted the action is performed<br /> on the person requesting the command.
                                                  </p>
                                                  
                                                  <p>
                                                    <strong>Syntax:</strong> <tt>OWNER|DEOWNER <#channel> [nickname]</tt>
                                                  </p>
                                                  
                                                  <p>
                                                    <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ OWNER #foo</tt><br /> <a name="PROTECT|DEPROTECT"><br /> <h2>
                                                      PROTECT|DEPROTECT
                                                    </h2>
                                                    
                                                    <p>
                                                      </a>
                                                    </p>
                                                    
                                                    <p>
                                                      These commands perform status mode changes on a channel.
                                                    </p>
                                                    
                                                    <p>
                                                      If you perform an operation on another user, they will be<br /> notified that you did it.
                                                    </p>
                                                    
                                                    <p>
                                                      If the last parameter is omitted the action is performed<br /> on the person requesting the command.
                                                    </p>
                                                    
                                                    <p>
                                                      <strong>Syntax:</strong> <tt>PROTECT|DEPROTECT <#channel> [nickname]</tt>
                                                    </p>
                                                    
                                                    <p>
                                                      <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ PROTECT #foo</tt><br /> <a name="RECOVER"><br /> <h2>
                                                        RECOVER
                                                      </h2>
                                                      
                                                      <p>
                                                        </a>
                                                      </p>
                                                      
                                                      <p>
                                                        RECOVER allows you to regain control of your<br /> channel in the event of a takeover.
                                                      </p>
                                                      
                                                      <p>
                                                        More precisely, everyone will be deopped,<br /> limit and key will be cleared, all bans<br /> matching you are removed, a ban exception<br /> matching you is added (in case of bans Atheme<br /> can&#8217;t see), the channel is set invite-only<br /> and moderated and you are invited.
                                                      </p>
                                                      
                                                      <p>
                                                        If you are on channel, you will be opped and<br /> no ban exception will be added.
                                                      </p>
                                                      
                                                      <p>
                                                        <strong>Syntax:</strong> <tt>RECOVER <#channel></tt>
                                                      </p>
                                                      
                                                      <p>
                                                        <strong>Example:</strong><br /> <br /><tt>/msg ChanServ RECOVER #foo</tt><br /> <a name="REGISTER"><br /> <h2>
                                                          REGISTER
                                                        </h2>
                                                        
                                                        <p>
                                                          </a>
                                                        </p>
                                                        
                                                        <p>
                                                          REGISTER allows you to register a channel<br /> so that you have better control. Registration<br /> allows you to maintain a channel access list<br /> and other functions that are normally<br /> provided by IRC bots.
                                                        </p>
                                                        
                                                        <p>
                                                          <strong>Syntax:</strong> <tt>REGISTER <#channel></tt>
                                                        </p>
                                                        
                                                        <p>
                                                          <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ REGISTER #atheme</tt><br /> <a name="ROLE ADD"><br /> <h2>
                                                            ROLE ADD
                                                          </h2>
                                                          
                                                          <p>
                                                            </a>
                                                          </p>
                                                          
                                                          <p>
                                                            ROLE ADD will create a channel role with the given<br /> flags. Multiple flags should be seperated by a space.
                                                          </p>
                                                          
                                                          <p>
                                                            <strong>Syntax:</strong> <tt>ROLE <#channel> ADD <role> [flags]</tt>
                                                          </p>
                                                          
                                                          <p>
                                                            Flags:<br /> <br /><tt>+voice - Enables use of the voice/devoice commands.</tt><br /> <br /><tt>+autovoice - Enables automatic voice.</tt><br /> <br /><tt>+halfop - Enables use of the halfop/dehalfop commands.</tt><br /> <br /><tt>+autohalfop - Enables automatic halfop.</tt><br /> <br /><tt>+op - Enables use of the op/deop commands.</tt><br /> <br /><tt>+autoop - Enables automatic op.</tt><br /> <br /><tt>+protect - Enables use of the protect/deprotect commands.</tt><br /> <br /><tt>+owner - Enables use of the owner/deowner commands.</tt><br /> <br /><tt>+set - Enables use of the set command.</tt><br /> <br /><tt>+invite - Enables use of the invite and getkey commands.</tt><br /> <br /><tt>+remove - Enables use of the kick, kickban, ban and unban commands.</tt><br /> <br /><tt>+remove - Enables use of the ban and unban commands.</tt><br /> <br /><tt>+remove - Enables use of the unban command.</tt><br /> <br /><tt>+recover - Enables use of the recover and clear commands.</tt><br /> <br /><tt>+acl-change - Enables modification of channel access lists.</tt><br /> <br /><tt>+topic - Enables use of the topic and topicappend commands.</tt><br /> <br /><tt>+acl-view - Enables viewing of channel access lists.</tt><br /> <br /><tt>+successor - Marks the user as a successor.</tt><br /> <br /><tt>+founder - Grants full founder access.</tt><br /> <br /><tt>+banned - Enables automatic kickban.</tt>
                                                          </p>
                                                          
                                                          <p>
                                                            <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ ROLE #atheme ADD helpers topic autovoice</tt><br /> <a name="ROLE DEL"><br /> <h2>
                                                              ROLE DEL
                                                            </h2>
                                                            
                                                            <p>
                                                              </a>
                                                            </p>
                                                            
                                                            <p>
                                                              ROLE DEL will delete a channel-specific role.
                                                            </p>
                                                            
                                                            <p>
                                                              <strong>Syntax:</strong> <tt>ROLE <#channel> DEL <role></tt>
                                                            </p>
                                                            
                                                            <p>
                                                              <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ ROLE #atheme DEL helpers</tt><br /> <a name="ROLE LIST"><br /> <h2>
                                                                ROLE LIST
                                                              </h2>
                                                              
                                                              <p>
                                                                </a>
                                                              </p>
                                                              
                                                              <p>
                                                                ROLE LIST lists all channel-specific and network-wide roles<br /> and the flags that each role has.
                                                              </p>
                                                              
                                                              <p>
                                                                <strong>Syntax:</strong> <tt>ROLE <#channel> LIST</tt>
                                                              </p>
                                                              
                                                              <p>
                                                                <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ ROLE #baz LIST</tt><br /> <a name="ROLE SET"><br /> <h2>
                                                                  ROLE SET
                                                                </h2>
                                                                
                                                                <p>
                                                                  </a>
                                                                </p>
                                                                
                                                                <p>
                                                                  ROLE SET allows you to modify the flags of a role that<br /> already exists. All users in the given role will recieve<br /> the effects of the changes. Multiple flags should be<br /> seperated by a space and have the modifier (+ or -) before<br /> each flag.
                                                                </p>
                                                                
                                                                <p>
                                                                  <strong>Syntax:</strong> <tt>ROLE <#channel> SET <role> <flags></tt>
                                                                </p>
                                                                
                                                                <p>
                                                                  <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ ROLE #atheme SET channel-ops +acl-change +set +recover</tt><br /> <br /><tt>/msg ChanServ ROLE #atheme SET helpers +invite</tt><br /> <br /><tt>/msg ChanServ ROLE #foo SET helpers -topic -invite</tt><br /> <a name="SET EMAIL"><br /> <h2>
                                                                    SET EMAIL
                                                                  </h2>
                                                                  
                                                                  <p>
                                                                    </a>
                                                                  </p>
                                                                  
                                                                  <p>
                                                                    SET EMAIL allows you to change or set the email<br /> address associated with a channel. This is shown<br /> to all users in INFO.
                                                                  </p>
                                                                  
                                                                  <p>
                                                                    <strong>Syntax:</strong> <tt>SET <#channel> EMAIL [email]</tt>
                                                                  </p>
                                                                  
                                                                  <p>
                                                                    Using the command in this way results in an email<br /> address being associated with the channel.
                                                                  </p>
                                                                  
                                                                  <p>
                                                                    <strong>Example:</strong><br /> <br /><tt>/msg ChanServ SET #chat EMAIL some@email.address</tt>
                                                                  </p>
                                                                  
                                                                  <p>
                                                                    <a name="SET ENTRYMSG"><br /> <h2>
                                                                      SET ENTRYMSG
                                                                    </h2>
                                                                    
                                                                    <p>
                                                                      </a>
                                                                    </p>
                                                                    
                                                                    <p>
                                                                      SET ENTRYMSG allows you to change or set<br /> a message sent to all users joining the<br /> channel.
                                                                    </p>
                                                                    
                                                                    <p>
                                                                      <strong>Syntax:</strong> <tt>SET <#channel> ENTRYMSG [message]</tt>
                                                                    </p>
                                                                    
                                                                    <p>
                                                                      <strong>Example:</strong><br /> <br /><tt>/msg ChanServ SET #support ENTRYMSG Welcome to #support. Please do not paste more than 5 lines.</tt><br /> <a name="SET FANTASY"><br /> <h2>
                                                                        SET FANTASY
                                                                      </h2>
                                                                      
                                                                      <p>
                                                                        </a>
                                                                      </p>
                                                                      
                                                                      <p>
                                                                        SET FANTASY allows you to enable or disable ChanServ<br /> fantasy commands (!op, !deop, etc.) on your channel.
                                                                      </p>
                                                                      
                                                                      <p>
                                                                        GUARD must be enabled as well for fantasy commands<br /> to work.
                                                                      </p>
                                                                      
                                                                      <p>
                                                                        <strong>Syntax:</strong> <tt>SET <#channel> FANTASY ON|OFF</tt>
                                                                      </p>
                                                                      
                                                                      <p>
                                                                        <strong>Example:</strong><br /> <br /><tt>/msg ChanServ SET #chatspike FANTASY ON</tt><br /> <a name="SET FOUNDER"><br /> <h2>
                                                                          SET FOUNDER
                                                                        </h2>
                                                                        
                                                                        <p>
                                                                          </a>
                                                                        </p>
                                                                        
                                                                        <p>
                                                                          SET FOUNDER allows you to set a new founder<br /> of the channel. The new founder has to<br /> execute the same command to confirm the<br /> transfer.
                                                                        </p>
                                                                        
                                                                        <p>
                                                                          <strong>Syntax:</strong> <tt>SET <#channel> FOUNDER <newnick></tt>
                                                                        </p>
                                                                        
                                                                        <p>
                                                                          If the new founder has not yet confirmed the<br /> transfer, you can cancel it by specifying<br /> your own nick as the new founder.
                                                                        </p>
                                                                        
                                                                        <p>
                                                                          <strong>Syntax:</strong> <tt>SET <#channel> FOUNDER <yournick></tt>
                                                                        </p>
                                                                        
                                                                        <p>
                                                                          <strong>Example:</strong><br /> <br /><tt>/msg ChanServ SET #foo FOUNDER bar</tt><br /> <a name="SET GUARD"><br /> <h2>
                                                                            SET GUARD
                                                                          </h2>
                                                                          
                                                                          <p>
                                                                            </a>
                                                                          </p>
                                                                          
                                                                          <p>
                                                                            SET GUARD allows you to have ChanServ join your channel.
                                                                          </p>
                                                                          
                                                                          <p>
                                                                            <strong>Syntax:</strong> <tt>SET <#channel> GUARD ON|OFF</tt>
                                                                          </p>
                                                                          
                                                                          <p>
                                                                            <strong>Example:</strong><br /> <br /><tt>/msg ChanServ SET #atheme GUARD ON</tt><br /> <a name="SET KEEPTOPIC"><br /> <h2>
                                                                              SET KEEPTOPIC
                                                                            </h2>
                                                                            
                                                                            <p>
                                                                              </a>
                                                                            </p>
                                                                            
                                                                            <p>
                                                                              SET KEEPTOPIC enables restoration of the old<br /> topic after the channel has become empty. In<br /> some cases, it may revert topic changes<br /> after netsplits or services outages, so it<br /> is not recommended to turn this on if your<br /> channel tends to never empty.
                                                                            </p>
                                                                            
                                                                            <p>
                                                                              <strong>Syntax:</strong> <tt>SET <#channel> KEEPTOPIC ON|OFF</tt>
                                                                            </p>
                                                                            
                                                                            <p>
                                                                              <strong>Example:</strong><br /> <br /><tt>/msg ChanServ SET #foo KEEPTOPIC ON</tt><br /> <a name="SET LIMITFLAGS"><br /> <h2>
                                                                                SET LIMITFLAGS
                                                                              </h2>
                                                                              
                                                                              <p>
                                                                                </a>
                                                                              </p>
                                                                              
                                                                              <p>
                                                                                SET LIMITFLAGS limits the power of the +f flag.
                                                                              </p>
                                                                              
                                                                              <p>
                                                                                Users with +f that have neither +s nor +R<br /> may only set +b (akick), and users that do not<br /> have all of +s and +R may not set +s, +R and<br /> +f.
                                                                              </p>
                                                                              
                                                                              <p>
                                                                                <strong>Syntax:</strong> <tt>SET <#channel> LIMITFLAGS ON|OFF</tt>
                                                                              </p>
                                                                              
                                                                              <p>
                                                                                <strong>Example:</strong><br /> <br /><tt>/msg ChanServ SET #foo LIMITFLAGS ON</tt><br /> <a name="SET MLOCK"><br /> <h2>
                                                                                  SET MLOCK
                                                                                </h2>
                                                                                
                                                                                <p>
                                                                                  </a>
                                                                                </p>
                                                                                
                                                                                <p>
                                                                                  MLOCK (or &#8220;mode lock&#8221;) allows you to enforce a set<br /> of modes on a channel. This can prevent abuse in cases<br /> such as +kl. It can also make it harder to fight evil<br /> bots, be careful. Locked modes can be seen by anyone<br /> recreating the channel (this includes keys).
                                                                                </p>
                                                                                
                                                                                <p>
                                                                                  <strong>Syntax:</strong> <tt>SET <#channel> MLOCK [modes]</tt>
                                                                                </p>
                                                                                
                                                                                <p>
                                                                                  Examples: (some may use modes your ircd does not support)<br /> <br /><tt>/msg ChanServ SET #foo MLOCK +nt-lk</tt><br /> <br /><tt>/msg ChanServ SET #foo MLOCK +inst-kl</tt><br /> <br /><tt>/msg ChanServ SET #c MLOCK +ntk c</tt><br /> <br /><tt>/msg ChanServ SET #foo MLOCK +ntcjf-kl 2:30 #overflow</tt><br /> <br /><tt>/msg ChanServ SET #overflow MLOCK +mntF-kljf</tt><br /> <br /><tt>/msg ChanServ SET #foo1 MLOCK +ntlL 40 #foo2</tt><br /> <a name="SET NOSYNC"><br /> <h2>
                                                                                    SET NOSYNC
                                                                                  </h2>
                                                                                  
                                                                                  <p>
                                                                                    </a>
                                                                                  </p>
                                                                                  
                                                                                  <p>
                                                                                    SET NOSYNC allows channel staff to disable<br /> automatic syncing of channel status when it<br /> is changed.
                                                                                  </p>
                                                                                  
                                                                                  <p>
                                                                                    <strong>Syntax:</strong> <tt>SET <#channel> NOSYNC ON|OFF</tt>
                                                                                  </p>
                                                                                  
                                                                                  <p>
                                                                                    <strong>Example:</strong><br /> <br /><tt>/msg ChanServ SET #foo NOSYNC ON</tt><br /> <a name="SET PREFIX"><br /> <h2>
                                                                                      SET PREFIX
                                                                                    </h2>
                                                                                    
                                                                                    <p>
                                                                                      </a>
                                                                                    </p>
                                                                                    
                                                                                    <p>
                                                                                      PREFIX allows you to customize the channel fantasy trigger<br /> for your channel. This is particularly useful if you have<br /> channel bots that conflict with ChanServ&#8217;s default fantasy<br /> prefix. Providing no prefix argument (or DEFAULT) resets<br /> the channel fantasy prefix to the network default prefix.
                                                                                    </p>
                                                                                    
                                                                                    <p>
                                                                                      <strong>Syntax:</strong> <tt>SET <#channel> PREFIX [prefix]</tt>
                                                                                    </p>
                                                                                    
                                                                                    <p>
                                                                                      <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ SET #foo PREFIX</tt><br /> <br /><tt>/msg ChanServ SET #foo PREFIX '</tt><br /> <br /><tt>/msg ChanServ SET #c PREFIX %</tt><br /> <br /><tt>/msg ChanServ SET #c PREFIX default</tt><br /> <a name="SET PRIVATE"><br /> <h2>
                                                                                        SET PRIVATE
                                                                                      </h2>
                                                                                      
                                                                                      <p>
                                                                                        </a>
                                                                                      </p>
                                                                                      
                                                                                      <p>
                                                                                        SET PRIVATE hides various information about<br /> the channel from other users.
                                                                                      </p>
                                                                                      
                                                                                      <p>
                                                                                        <strong>Syntax:</strong> <tt>SET <#channel> PRIVATE ON|OFF</tt>
                                                                                      </p>
                                                                                      
                                                                                      <p>
                                                                                        <strong>Example:</strong><br /> <br /><tt>/msg ChanServ SET #foo PRIVATE ON</tt><br /> <a name="SET RESTRICTED"><br /> <h2>
                                                                                          SET RESTRICTED
                                                                                        </h2>
                                                                                        
                                                                                        <p>
                                                                                          </a>
                                                                                        </p>
                                                                                        
                                                                                        <p>
                                                                                          SET RESTRICTED designates a channel as restricted access.<br /> Users who are not on the access list of the channel,<br /> or who do not have the chan:joinstaffonly privilege<br /> will be kicked and banned from the channel upon join,<br /> removing any ban exceptions matching them first.<br /> If the channel is set +i, no ban will be set<br /> and invite exceptions will be removed.
                                                                                        </p>
                                                                                        
                                                                                        <p>
                                                                                          <strong>Syntax:</strong> <tt>SET <#channel> RESTRICTED ON|OFF</tt>
                                                                                        </p>
                                                                                        
                                                                                        <p>
                                                                                          <strong>Example:</strong><br /> <br /><tt>/msg ChanServ SET #snoop RESTRICTED ON</tt><br /> <a name="SET SECURE"><br /> <h2>
                                                                                            SET SECURE
                                                                                          </h2>
                                                                                          
                                                                                          <p>
                                                                                            </a>
                                                                                          </p>
                                                                                          
                                                                                          <p>
                                                                                            SET SECURE prevents anyone that&#8217;s not on the<br /> channel&#8217;s access lists from gaining operator<br /> or halfop status on the channel. This is<br /> useful if you&#8217;re paranoid.
                                                                                          </p>
                                                                                          
                                                                                          <p>
                                                                                            <strong>Syntax:</strong> <tt>SET <#channel> SECURE ON|OFF</tt>
                                                                                          </p>
                                                                                          
                                                                                          <p>
                                                                                            <strong>Example:</strong><br /> <br /><tt>/msg ChanServ SET #foo SECURE ON</tt><br /> <a name="SET TOPICLOCK"><br /> <h2>
                                                                                              SET TOPICLOCK
                                                                                            </h2>
                                                                                            
                                                                                            <p>
                                                                                              </a>
                                                                                            </p>
                                                                                            
                                                                                            <p>
                                                                                              SET TOPICLOCK causes ChanServ to revert<br /> topic changes by users without the +t flag.<br /> Topic changes during netsplits or services<br /> outages will always be reverted.
                                                                                            </p>
                                                                                            
                                                                                            <p>
                                                                                              TOPICLOCK requires KEEPTOPIC and will<br /> automatically enable it; disabling KEEPTOPIC<br /> will disable TOPICLOCK also.
                                                                                            </p>
                                                                                            
                                                                                            <p>
                                                                                              <strong>Syntax:</strong> <tt>SET <#channel> TOPICLOCK ON|OFF</tt>
                                                                                            </p>
                                                                                            
                                                                                            <p>
                                                                                              <strong>Example:</strong><br /> <br /><tt>/msg ChanServ SET #foo TOPICLOCK ON</tt><br /> <a name="SET URL"><br /> <h2>
                                                                                                SET URL
                                                                                              </h2>
                                                                                              
                                                                                              <p>
                                                                                                </a>
                                                                                              </p>
                                                                                              
                                                                                              <p>
                                                                                                SET URL allows you to change or set the URL<br /> associated with a channel. This is shown<br /> to all users joining the channel.
                                                                                              </p>
                                                                                              
                                                                                              <p>
                                                                                                <strong>Syntax:</strong> <tt>SET <#channel> URL <a href=""></a></tt>
                                                                                              </p>
                                                                                              
                                                                                              <p>
                                                                                                <strong>Example:</strong><br /> <br /><tt>/msg ChanServ SET #chat URL http://slashdot.org</tt><br /> <a name="SET VERBOSE"><br /> <h2>
                                                                                                  SET VERBOSE
                                                                                                </h2>
                                                                                                
                                                                                                <p>
                                                                                                  </a>
                                                                                                </p>
                                                                                                
                                                                                                <p>
                                                                                                  SET VERBOSE ON sends a notice to the channel when someone<br /> makes changes to the access lists.
                                                                                                </p>
                                                                                                
                                                                                                <p>
                                                                                                  SET VERBOSE OPS sends a notice to the channel operators when<br /> someone makes changes to the access lists.
                                                                                                </p>
                                                                                                
                                                                                                <p>
                                                                                                  Fantasy commands are always executed as if SET VERBOSE ON is<br /> in effect.
                                                                                                </p>
                                                                                                
                                                                                                <p>
                                                                                                  <strong>Syntax:</strong> <tt>SET <#channel> VERBOSE ON|OPS|OFF</tt>
                                                                                                </p>
                                                                                                
                                                                                                <p>
                                                                                                  <strong>Example:</strong><br /> <br /><tt>/msg ChanServ SET #foo VERBOSE ON</tt><br /> <a name="STATUS"><br /> <h2>
                                                                                                    STATUS
                                                                                                  </h2>
                                                                                                  
                                                                                                  <p>
                                                                                                    </a>
                                                                                                  </p>
                                                                                                  
                                                                                                  <p>
                                                                                                    STATUS returns information about your current<br /> state. It will show information about your<br /> nickname, IRC operator, and SRA status.
                                                                                                  </p>
                                                                                                  
                                                                                                  <p>
                                                                                                    If the a channel parameter is specified, your<br /> access to the given channel is returned.
                                                                                                  </p>
                                                                                                  
                                                                                                  <p>
                                                                                                    <strong>Syntax:</strong> <tt>STATUS [#channel]</tt>
                                                                                                  </p>
                                                                                                  
                                                                                                  <p>
                                                                                                    <strong>Example:</strong><br /> <br /><tt>/msg ChanServ STATUS</tt><br /> <br /><tt>/msg ChanServ STATUS #foo</tt><br /> <a name="SYNC"><br /> <h2>
                                                                                                      SYNC
                                                                                                    </h2>
                                                                                                    
                                                                                                    <p>
                                                                                                      </a>
                                                                                                    </p>
                                                                                                    
                                                                                                    <p>
                                                                                                      The SYNC command will force all channel statuses to flags, giving and taking<br /> away ops, voice and so on where necessary. You must have the channel flag +R to<br /> run this command.
                                                                                                    </p>
                                                                                                    
                                                                                                    <p>
                                                                                                      <strong>Syntax:</strong> <tt>SYNC <#channel></tt>
                                                                                                    </p>
                                                                                                    
                                                                                                    <p>
                                                                                                      <strong>Examples:</strong><br /> <tt>/msg ChanServ SYNC #bar</tt><br /> <a name="TEMPLATE"><br /> <h2>
                                                                                                        TEMPLATE
                                                                                                      </h2>
                                                                                                      
                                                                                                      <p>
                                                                                                        </a>
                                                                                                      </p>
                                                                                                      
                                                                                                      <p>
                                                                                                        The TEMPLATE command allows definition of sets of flags,<br /> simplifying the use of the FLAGS command.
                                                                                                      </p>
                                                                                                      
                                                                                                      <p>
                                                                                                        Without arguments, network wide templates are shown.<br /> These include at least SOP/AOP/HOP/VOP.<br /> These include at least SOP/AOP/VOP.
                                                                                                      </p>
                                                                                                      
                                                                                                      <p>
                                                                                                        <strong>Syntax:</strong> <tt>TEMPLATE</tt>
                                                                                                      </p>
                                                                                                      
                                                                                                      <p>
                                                                                                        When given only the channel argument, a listing of<br /> templates for the channel will be displayed.
                                                                                                      </p>
                                                                                                      
                                                                                                      <p>
                                                                                                        <strong>Syntax:</strong> <tt>TEMPLATE <#channel></tt>
                                                                                                      </p>
                                                                                                      
                                                                                                      <p>
                                                                                                        Otherwise, a template is modified. A modification may be<br /> specified by a template name (copies the template) or a<br /> flags change (starts with + or -, optionally preceded by<br /> an !). Templates cannot be the empty set (making a<br /> template empty deletes it).
                                                                                                      </p>
                                                                                                      
                                                                                                      <p>
                                                                                                        If the ! form is used, all access entries which exactly<br /> match the template are changed accordingly. This is<br /> not supported if the template includes or included<br /> founder access (+F).
                                                                                                      </p>
                                                                                                      
                                                                                                      <p>
                                                                                                        There is a limit on the length of all templates on a<br /> channel.
                                                                                                      </p>
                                                                                                      
                                                                                                      <p>
                                                                                                        If you are not a founder, similar restrictions apply<br /> as in FLAGS.
                                                                                                      </p>
                                                                                                      
                                                                                                      <p>
                                                                                                        <strong>Syntax:</strong> <tt>TEMPLATE <#channel> [template oldtemplate]</tt><br /> <strong>Syntax:</strong> <tt>TEMPLATE <#channel> [template flag_changes]</tt><br /> <strong>Syntax:</strong> <tt>TEMPLATE <#channel> [template !flag_changes]</tt>
                                                                                                      </p>
                                                                                                      
                                                                                                      <p>
                                                                                                        <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ TEMPLATE #foo</tt><br /> <br /><tt>/msg ChanServ TEMPLATE #foo user VOP</tt><br /> <br /><tt>/msg ChanServ TEMPLATE #foo user !+A</tt><br /> <br /><tt>/msg ChanServ TEMPLATE #foo co-founder +*-OH</tt><br /> <br /><tt>/msg ChanServ TEMPLATE #foo op -*+vVhoti</tt><br /> <br /><tt>/msg ChanServ TEMPLATE #foo co-founder +*-O</tt><br /> <br /><tt>/msg ChanServ TEMPLATE #foo op -*+vVoti</tt><br /> <br /><tt>/msg ChanServ TEMPLATE #foo obsoletetemplate -*</tt><br /> <a name="TOPIC"><br /> <h2>
                                                                                                          TOPIC
                                                                                                        </h2>
                                                                                                        
                                                                                                        <p>
                                                                                                          </a>
                                                                                                        </p>
                                                                                                        
                                                                                                        <p>
                                                                                                          The TOPIC command allows for the changing of a topic on a channel.
                                                                                                        </p>
                                                                                                        
                                                                                                        <p>
                                                                                                          <strong>Syntax:</strong> <tt>TOPIC <#channel> <topic></tt>
                                                                                                        </p>
                                                                                                        
                                                                                                        <p>
                                                                                                          <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ TOPIC #foo bar</tt><br /> <a name="TOPICAPPEND"><br /> <h2>
                                                                                                            TOPICAPPEND
                                                                                                          </h2>
                                                                                                          
                                                                                                          <p>
                                                                                                            </a>
                                                                                                          </p>
                                                                                                          
                                                                                                          <p>
                                                                                                            The TOPICAPPEND command allows for the addition to a topic on a channel.
                                                                                                          </p>
                                                                                                          
                                                                                                          <p>
                                                                                                            <strong>Syntax:</strong> <tt>TOPICAPPEND <#channel> <topic></tt>
                                                                                                          </p>
                                                                                                          
                                                                                                          <p>
                                                                                                            <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ TOPICAPPEND #foo bar</tt><br /> <a name="TOPICPREPEND"><br /> <h2>
                                                                                                              TOPICPREPEND
                                                                                                            </h2>
                                                                                                            
                                                                                                            <p>
                                                                                                              </a>
                                                                                                            </p>
                                                                                                            
                                                                                                            <p>
                                                                                                              The TOPICPREPEND command allows for the addition to a topic on a channel.
                                                                                                            </p>
                                                                                                            
                                                                                                            <p>
                                                                                                              <strong>Syntax:</strong> <tt>TOPICPREPEND <#channel> <topic></tt>
                                                                                                            </p>
                                                                                                            
                                                                                                            <p>
                                                                                                              <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ TOPICPREPEND #foo bar</tt><br /> <a name="UNBAN"><br /> <h2>
                                                                                                                UNBAN
                                                                                                              </h2>
                                                                                                              
                                                                                                              <p>
                                                                                                                </a>
                                                                                                              </p>
                                                                                                              
                                                                                                              <p>
                                                                                                                The UNBAN command allows you to unban a user or hostmask<br /> from a channel. If no nickname or hostmask is specified,<br /> you are unbanned.
                                                                                                              </p>
                                                                                                              
                                                                                                              <p>
                                                                                                                <strong>Syntax:</strong> <tt>UNBAN <#channel> [nickname|hostmask]</tt>
                                                                                                              </p>
                                                                                                              
                                                                                                              <p>
                                                                                                                <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ UNBAN #chat pfish</tt><br /> <br /><tt>/msg ChanServ UNBAN #chat *!*@*.ucdavis.edu</tt><br /> <a name="UNBAN"><br /> <h2>
                                                                                                                  UNBAN
                                                                                                                </h2>
                                                                                                                
                                                                                                                <p>
                                                                                                                  </a>
                                                                                                                </p>
                                                                                                                
                                                                                                                <p>
                                                                                                                  The UNBAN command allows you to remove all bans matching<br /> you from a channel.
                                                                                                                </p>
                                                                                                                
                                                                                                                <p>
                                                                                                                  <strong>Syntax:</strong> <tt>UNBAN <#channel></tt>
                                                                                                                </p>
                                                                                                                
                                                                                                                <p>
                                                                                                                  <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ UNBAN #chat</tt><br /> <a name="WHY"><br /> <h2>
                                                                                                                    WHY
                                                                                                                  </h2>
                                                                                                                  
                                                                                                                  <p>
                                                                                                                    </a>
                                                                                                                  </p>
                                                                                                                  
                                                                                                                  <p>
                                                                                                                    The WHY command shows the access entries an online<br /> user matches.
                                                                                                                  </p>
                                                                                                                  
                                                                                                                  <p>
                                                                                                                    <strong>Syntax:</strong> <tt>WHY <#channel> [nickname]</tt>
                                                                                                                  </p>
                                                                                                                  
                                                                                                                  <p>
                                                                                                                    <strong>Examples:</strong><br /> <br /><tt>/msg ChanServ WHY #atheme jilles^</tt>
                                                                                                                  </p>