---
title: MemoServ
author: MrRandom
layout: page
---
<a name="DELETE"><br /> <h2>
  DELETE
</h2>

<p>
  </a>
</p>

<p>
  DELETE allows you to delete memos from your<br /> inbox. You can delete all memos with the<br /> <b>ALL</b> parameter, all read memos with the <b>OLD</b><br /> parameter, or specify a memo number.
</p>

<p>
  You can obtain a memo number by using the LIST<br /> command. Once you delete a memo, the numbers of<br /> all subsequent memos will change.
</p>

<p>
  You can also SEND, READ, LIST and FORWARD memos.
</p>

<p>
  <strong>Syntax:</strong> <tt>DELETE ALL|OLD|<memo number></tt>
</p>

<p>
  <strong>Examples:</strong><br /> <br /><tt>/msg MemoServ DELETE OLD</tt><br /> <br /><tt>/msg MemoServ DELETE 1</tt><br /> <a name="FORWARD"><br /> <h2>
    FORWARD
  </h2>
  
  <p>
    </a>
  </p>
  
  <p>
    FORWARD allows you to forward a memo to another<br /> account. Useful for a variety of reasons.
  </p>
  
  <p>
    You can also SEND, DELETE, LIST or READ memos.
  </p>
  
  <p>
    <strong>Syntax:</strong> <tt>FORWARD <user|nick> <memo number></tt>
  </p>
  
  <p>
    <strong>Examples:</strong><br /> <br /><tt>/msg MemoServ FORWARD kog 1</tt><br /> <a name="IGNORE"><br /> <h2>
      IGNORE
    </h2>
    
    <p>
      </a>
    </p>
    
    <p>
      IGNORE allows you to ignore memos from another<br /> user. Possible reasons include inbox spamming,<br /> annoying users, bots that have figured out how<br /> to register etc.
    </p>
    
    <p>
      You can add up to 40 users to your ignore list
    </p>
    
    <p>
      <strong>Syntax:</strong> <tt>IGNORE ADD|DEL|LIST|CLEAR <account></tt>
    </p>
    
    <p>
      <strong>Examples:</strong><br /> <br /><tt>/msg MemoServ IGNORE ADD kog</tt><br /> <br /><tt>/msg MemoServ IGNORE DEL kog</tt><br /> <br /><tt>/msg MemoServ IGNORE LIST</tt><br /> <br /><tt>/msg MemoServ IGNORE CLEAR</tt><br /> <a name="LIST"><br /> <h2>
        LIST
      </h2>
      
      <p>
        </a>
      </p>
      
      <p>
        LIST shows you your memos in your inbox,<br /> including who sent them and when. To read a<br /> memo, use the READ command. You can also<br /> DELETE or FORWARD a memo.
      </p>
      
      <p>
        <strong>Syntax:</strong> <tt>LIST</tt>
      </p>
      
      <p>
        <strong>Examples:</strong><br /> <br /><tt>/msg MemoServ LIST</tt><br /> <a name="READ"><br /> <h2>
          READ
        </h2>
        
        <p>
          </a>
        </p>
        
        <p>
          READ allows you to read a memo that another<br /> user has sent you. You can either read a memo<br /> by number or read your new memos.
        </p>
        
        <p>
          <strong>Syntax:</strong> <tt>READ <memo number></tt><br /> <strong>Syntax:</strong> <tt>READ NEW</tt>
        </p>
        
        <p>
          <strong>Examples:</strong><br /> <br /><tt>/msg MemoServ READ 1</tt><br /> <a name="SEND"><br /> <h2>
            SEND
          </h2>
          
          <p>
            </a>
          </p>
          
          <p>
            SEND allows you to send a memo to a nickname<br /> that is offline at the moment. When they<br /> come online they will be told they have messages<br /> waiting for them and will have an opportunity<br /> to read your memo.
          </p>
          
          <p>
            Your memo cannot be more than 300 characters.
          </p>
          
          <p>
            <strong>Syntax:</strong> <tt>SEND <user|nick> text</tt>
          </p>
          
          <p>
            <strong>Examples:</strong><br /> <br /><tt>/msg MemoServ SEND Kog pay your bills</tt><br /> <a name="SENDGROUP"><br /> <h2>
              SENDGROUP
            </h2>
            
            <p>
              </a>
            </p>
            
            <p>
              SENDGROUP allows you to send a memo to all members<br /> of a group who have the +m flag.
            </p>
            
            <p>
              <strong>Syntax:</strong> <tt>SENDGROUP <!group> <text></tt>
            </p>
            
            <p>
              <strong>Examples:</strong><br /> <br /><tt>/msg MemoServ SENDGROUP !opers beware of badguy</tt><br /> <a name="SENDOPS"><br /> <h2>
                SENDOPS
              </h2>
              
              <p>
                </a>
              </p>
              
              <p>
                SENDOPS allows you to send a memo to all ops<br /> on a channel. Only users allowed to view the<br /> access list can do this.
              </p>
              
              <p>
                <strong>Syntax:</strong> <tt>SENDOPS <#channel> <text></tt>
              </p>
              
              <p>
                <strong>Examples:</strong><br /> <br /><tt>/msg MemoServ SENDOPS #chat beware of badguy</tt>
              </p>